"""Adult reference ranges and plain-language names (US conventional units).

Ranges are typical textbook values for education only; real laboratories
publish their own ranges.
"""

REFERENCE: dict[str, dict] = {
    # key: name, unit, low, high, optional sex-specific ranges, critical limits
    "glucose":     dict(name="Fasting glucose", plain="blood sugar", unit="mg/dL", low=70, high=99, crit_low=50, crit_high=400),
    "hba1c":       dict(name="HbA1c", plain="3-month average blood sugar", unit="%", low=4.0, high=5.6),
    "total_chol":  dict(name="Total cholesterol", plain="total cholesterol", unit="mg/dL", low=0, high=199),
    "ldl":         dict(name="LDL cholesterol", plain="'bad' cholesterol", unit="mg/dL", low=0, high=99),
    "hdl":         dict(name="HDL cholesterol", plain="'good' cholesterol", unit="mg/dL", low=40, high=999, low_F=50),
    "tg":          dict(name="Triglycerides", plain="blood fats", unit="mg/dL", low=0, high=149),
    "creatinine":  dict(name="Creatinine", plain="kidney waste marker", unit="mg/dL", low=0.6, high=1.3, high_F=1.1),
    "bun":         dict(name="BUN", plain="urea (kidney marker)", unit="mg/dL", low=7, high=20),
    "alt":         dict(name="ALT", plain="liver enzyme", unit="U/L", low=7, high=40, high_F=33),
    "ast":         dict(name="AST", plain="liver enzyme", unit="U/L", low=10, high=40, high_F=32),
    "hemoglobin":  dict(name="Hemoglobin", plain="oxygen-carrying red cell protein", unit="g/dL", low=13.5, high=17.5, low_F=12.0, high_F=15.5, crit_low=7),
    "mcv":         dict(name="MCV", plain="red blood cell size", unit="fL", low=80, high=100),
    "wbc":         dict(name="White cell count", plain="infection-fighting cells", unit="x10^9/L", low=4.0, high=11.0, crit_high=30),
    "platelets":   dict(name="Platelets", plain="clotting cells", unit="x10^9/L", low=150, high=400, crit_low=20),
    "crp":         dict(name="CRP", plain="inflammation marker", unit="mg/L", low=0, high=10),
    "potassium":   dict(name="Potassium", plain="potassium", unit="mmol/L", low=3.5, high=5.0, crit_low=2.8, crit_high=6.2),
    "sodium":      dict(name="Sodium", plain="salt balance", unit="mmol/L", low=135, high=145, crit_low=120, crit_high=160),
    "tsh":         dict(name="TSH", plain="thyroid signal", unit="mIU/L", low=0.4, high=4.5),
    "ferritin":    dict(name="Ferritin", plain="iron stores", unit="ng/mL", low=30, high=400, low_F=15, high_F=200),
    "vitamin_d":   dict(name="25-OH vitamin D", plain="vitamin D", unit="ng/mL", low=30, high=100),
    "b12":         dict(name="Vitamin B12", plain="vitamin B12", unit="pg/mL", low=200, high=900),
    "uacr":        dict(name="Urine albumin/creatinine", plain="protein leaking into urine", unit="mg/g", low=0, high=29),
    "nt_probnp":   dict(name="NT-proBNP", plain="heart strain marker", unit="pg/mL", low=0, high=125),
}

# Common aliases accepted when loading lab CSVs from public datasets.
ALIASES = {
    "fasting_glucose": "glucose", "glu": "glucose", "a1c": "hba1c", "hgba1c": "hba1c",
    "cholesterol": "total_chol", "chol": "total_chol", "ldl_c": "ldl", "hdl_c": "hdl",
    "triglycerides": "tg", "creat": "creatinine", "cr": "creatinine", "hgb": "hemoglobin",
    "hb": "hemoglobin", "k": "potassium", "na": "sodium", "white_blood_cells": "wbc",
    "plt": "platelets", "c_reactive_protein": "crp", "vitd": "vitamin_d",
    "vitamin_b12": "b12", "ntprobnp": "nt_probnp", "albumin_creatinine_ratio": "uacr",
}


def bounds(key: str, sex: str) -> tuple[float, float]:
    r = REFERENCE[key]
    lo = r.get(f"low_{sex}", r["low"])
    hi = r.get(f"high_{sex}", r["high"])
    return lo, hi
