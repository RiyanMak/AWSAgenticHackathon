"""Care-team orchestrator.

Agents declare `depends_on`; the orchestrator groups them into stages
(topological order) and runs each stage concurrently:

    Stage 1: Lab Analyst  ||  Radiologist          (raw data -> findings)
    Stage 2: Doctor                                (findings -> diagnosis + plan)
    Stage 3: Nutritionist ||  Physiotherapist      (plan -> lifestyle programmes)

After the stages, a short "team huddle" cross-checks the outputs for
contradictions before the patient report is written.
"""
from __future__ import annotations

import time
from concurrent.futures import ThreadPoolExecutor

from .agents.doctor import Doctor
from .agents.lab_analyst import LabAnalyst
from .agents.nutritionist import Nutritionist
from .agents.physio import Physiotherapist
from .agents.radiologist import Radiologist
from .llm import LLM
from .models import CaseFile


class CareTeam:
    def __init__(self, llm: LLM | None = None):
        self.llm = llm or LLM()
        self.agents = [LabAnalyst(self.llm), Radiologist(self.llm), Doctor(self.llm),
                       Nutritionist(self.llm), Physiotherapist(self.llm)]

    def stages(self) -> list[list]:
        done, remaining, out = set(), list(self.agents), []
        while remaining:
            ready = [a for a in remaining if set(a.depends_on) <= done]
            if not ready:
                raise RuntimeError("circular agent dependencies")
            out.append(ready)
            done |= {a.name for a in ready}
            remaining = [a for a in remaining if a not in ready]
        return out

    def run(self, case: CaseFile) -> CaseFile:
        mode = f"Claude ({self.llm.model})" if self.llm.available else "offline rule engine"
        case.log(f"Care team convened for {case.patient.name} [{case.data_source}] - narration: {mode}")
        for i, stage in enumerate(self.stages(), 1):
            t0 = time.time()
            case.log(f"Stage {i}: " + " || ".join(a.persona for a in stage))
            with ThreadPoolExecutor(max_workers=len(stage)) as pool:
                list(pool.map(lambda a: a.run(case), stage))
            case.log(f"Stage {i} finished in {time.time() - t0:.2f}s")
        self.huddle(case)
        return case

    @staticmethod
    def huddle(case: CaseFile) -> None:
        """Cross-agent consistency checks."""
        doc = case.reports["doctor"].measurements
        phys = case.reports["physio"].measurements
        nut = case.reports["nutritionist"].measurements
        issues = []
        if doc["urgency"].startswith(("EMERGENCY", "SAME DAY")) and phys["intensity"] == "moderate":
            phys["intensity"] = "light"
            issues.append("Physio intensity lowered to light because the Doctor triaged as urgent.")
        if "cap" in case.all_codes() and nut["goal"].startswith("gradual weight loss"):
            issues.append("Nutritionist weight-loss goal postponed until infection resolves.")
        rx = {r["drug"].split()[0].lower() for r in case.reports["doctor"].recommendations}
        if "ferrous" in rx and ({"levofloxacin", "doxycycline"} & rx):
            issues.append("Iron and antibiotic both prescribed: dose spacing of 2 h added to instructions.")
        case.reports["doctor"].measurements["huddle"] = issues or ["No conflicts between agents."]
        for msg in issues or ["No conflicts between agents."]:
            case.log(f"[Huddle] {msg}")
