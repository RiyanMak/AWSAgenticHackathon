"""EKG (single lead) signal processing: filtering, R-peak detection,
heart-rate variability, P-wave presence and QRS width."""
from __future__ import annotations

import numpy as np
from scipy import signal


def bandpass(x: np.ndarray, fs: int, lo: float = 0.5, hi: float = 40.0) -> np.ndarray:
    b, a = signal.butter(3, [lo / (fs / 2), hi / (fs / 2)], btype="band")
    y = signal.filtfilt(b, a, x)
    # Notch out mains hum (both 50 and 60 Hz, harmless if absent).
    for f0 in (50.0, 60.0):
        if f0 < fs / 2:
            bn, an = signal.iirnotch(f0, 30, fs)
            y = signal.filtfilt(bn, an, y)
    return y


def detect_r_peaks(x: np.ndarray, fs: int) -> np.ndarray:
    """Pan-Tompkins-style: slope energy envelope, then refine to the local max."""
    d = np.gradient(x)
    energy = np.convolve(d ** 2, np.ones(int(0.12 * fs)) / (0.12 * fs), mode="same")
    thr = 0.3 * np.percentile(energy, 99)
    cand, _ = signal.find_peaks(energy, height=thr, distance=int(0.27 * fs))
    peaks = []
    w = int(0.08 * fs)
    for c in cand:
        lo, hi = max(0, c - w), min(len(x), c + w)
        peaks.append(lo + int(np.argmax(x[lo:hi])))
    peaks = np.unique(np.array(peaks, dtype=int))
    # Drop refined peaks that collapsed onto each other.
    if len(peaks) > 1:
        keep = np.insert(np.diff(peaks) > int(0.25 * fs), 0, True)
        peaks = peaks[keep]
    return peaks


def analyze_ekg(raw: np.ndarray, fs: int) -> dict:
    x = bandpass(np.asarray(raw, dtype=float), fs)
    peaks = detect_r_peaks(x, fs)
    out: dict = {"duration_s": round(len(x) / fs, 1), "beats": int(len(peaks))}
    if len(peaks) < 4:
        out["quality"] = "poor"
        return out

    rr = np.diff(peaks) / fs
    hr = 60.0 / rr.mean()
    succ = np.abs(np.diff(rr))
    out.update(
        quality="good",
        heart_rate_bpm=round(float(hr), 0),
        rr_mean_ms=round(float(rr.mean() * 1000), 0),
        sdnn_ms=round(float(rr.std() * 1000), 0),
        rmssd_ms=round(float(np.sqrt(np.mean(np.diff(rr) ** 2)) * 1000), 0),
        rr_cv=round(float(rr.std() / rr.mean()), 3),
        # Fraction of successive RR changes > 50 ms: high in AF.
        pnn50=round(float(np.mean(succ > 0.05)), 2),
    )

    # P-wave presence. Sinus P waves sit at a fixed distance before every R,
    # so the pre-R segment looks the same beat after beat. In AF the segment
    # is a mix of chaotic f-waves and T waves at varying positions. We build
    # a median template of the pre-R segment and count beats whose segment
    # correlates with it and shows a positive hump.
    a_off, b_off = int(0.24 * fs), int(0.06 * fs)
    segs = []
    for p in peaks:
        if p - a_off >= 0:
            s = x[p - a_off:p - b_off]
            segs.append(s - s[-1])          # reference to just before QRS
    p_frac, p_amp = 0.0, 0.0
    if len(segs) >= 3:
        segs = np.array(segs)
        tmpl = np.median(segs, axis=0)
        p_amp = float(tmpl.max() - np.min(tmpl[[0, -1]]))
        corr = [np.corrcoef(s, tmpl)[0, 1] for s in segs]
        r_amp = float(np.median(x[peaks]))
        has_hump = p_amp > 0.05 * r_amp
        p_frac = float(np.mean(np.array(corr) > 0.8)) if has_hump else 0.0
    out["p_wave_fraction"] = round(p_frac, 2)
    out["p_wave_amp_mv"] = round(p_amp, 2)

    # QRS width: contiguous region around R where the slope is steep.
    widths = []
    d = np.abs(np.gradient(x))
    for p in peaks:
        lo, hi = max(0, p - int(0.1 * fs)), min(len(x), p + int(0.1 * fs))
        local = d[lo:hi]
        thr = 0.08 * local.max()
        active = np.where(local > thr)[0]
        if len(active):
            widths.append((active[-1] - active[0]) / fs * 1000)
    out["qrs_ms"] = round(float(np.median(widths)), 0) if widths else None

    # Rhythm classification.
    cv, pnn, pf = out["rr_cv"], out["pnn50"], out["p_wave_fraction"]
    if (cv > 0.12 and pnn > 0.4 and pf < 0.7) or (cv > 0.2 and pnn > 0.6):
        rhythm = "atrial_fibrillation"
    elif cv > 0.12:
        rhythm = "irregular_rhythm"         # e.g. frequent ectopic beats
    elif hr > 100:
        rhythm = "sinus_tachycardia"
    elif hr < 50:
        rhythm = "sinus_bradycardia"
    else:
        rhythm = "normal_sinus_rhythm"
    out["rhythm"] = rhythm
    out["_filtered"] = x
    out["_peaks"] = peaks
    return out
