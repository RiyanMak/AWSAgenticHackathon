"""Shared data structures passed between agents.

Every agent reads from and writes to a single `CaseFile` (a blackboard).
Structured findings drive all downstream decisions; free-text narration is
only ever layered on top, so safety rules always run on the structured data.
"""
from __future__ import annotations

from dataclasses import dataclass, field, asdict
from typing import Any
import numpy as np


@dataclass
class Patient:
    patient_id: str
    name: str
    age: int
    sex: str                    # "M" or "F"
    weight_kg: float
    height_cm: float
    activity_level: str = "light"           # sedentary | light | moderate | active
    history: list[str] = field(default_factory=list)       # e.g. ["hypertension"]
    current_meds: list[str] = field(default_factory=list)
    allergies: list[str] = field(default_factory=list)
    symptoms: list[str] = field(default_factory=list)
    diet_preference: str = "omnivore"       # omnivore | vegetarian | vegan
    vitals: dict[str, Any] = field(default_factory=dict)  # bp "120/80", hr, rr, temp_c, spo2

    @property
    def bmi(self) -> float:
        return round(self.weight_kg / (self.height_cm / 100) ** 2, 1)


@dataclass
class LabValue:
    test: str          # canonical key, e.g. "hba1c"
    value: float
    unit: str = ""


@dataclass
class Finding:
    """One observation an agent is willing to stand behind."""
    code: str                  # machine key, e.g. "hyperglycemia", "atrial_fibrillation"
    label: str                 # clinician wording
    severity: str = "mild"     # normal | mild | moderate | severe | critical
    evidence: list[str] = field(default_factory=list)
    plain_language: str = ""   # patient wording
    confidence: float = 0.8

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


@dataclass
class AgentReport:
    agent: str
    persona: str
    findings: list[Finding] = field(default_factory=list)
    measurements: dict[str, Any] = field(default_factory=dict)
    recommendations: list[dict[str, Any]] = field(default_factory=list)
    patient_summary: str = ""
    warnings: list[str] = field(default_factory=list)

    def codes(self) -> set[str]:
        return {f.code for f in self.findings}


@dataclass
class CaseFile:
    """The blackboard every agent shares."""
    patient: Patient
    labs: list[LabValue] = field(default_factory=list)
    image: np.ndarray | None = None          # 2-D grayscale, float 0..1
    image_modality: str = "chest_xray_pa"
    ekg: np.ndarray | None = None            # 1-D lead II, millivolts
    ekg_fs: int = 250
    reports: dict[str, AgentReport] = field(default_factory=dict)
    trace: list[str] = field(default_factory=list)
    data_source: str = "synthetic"

    def lab(self, key: str) -> float | None:
        for lv in self.labs:
            if lv.test == key:
                return lv.value
        return None

    def all_codes(self) -> set[str]:
        out: set[str] = set()
        for r in self.reports.values():
            out |= r.codes()
        return out

    def finding(self, code: str) -> Finding | None:
        for r in self.reports.values():
            for f in r.findings:
                if f.code == code:
                    return f
        return None

    def log(self, msg: str) -> None:
        self.trace.append(msg)
