"""Optional Claude backend.

Agents always produce structured, rule-checked output first. When
ANTHROPIC_API_KEY is set (and the `anthropic` package is installed) each
persona can additionally ask Claude to (a) write its patient-facing summary
in its own voice and (b) for the Radiologist, give a second read of the
image. LLM text never changes structured findings or prescriptions.
"""
from __future__ import annotations

import base64
import io
import os

import numpy as np

DEFAULT_MODEL = os.environ.get("MEDTEAM_MODEL", "claude-sonnet-5-5")


class LLM:
    def __init__(self, model: str | None = None, enabled: bool | None = None):
        self.model = model or DEFAULT_MODEL
        self._client = None
        want = enabled if enabled is not None else bool(os.environ.get("ANTHROPIC_API_KEY"))
        if want:
            try:
                import anthropic
                self._client = anthropic.Anthropic()
            except Exception:          # SDK missing or key invalid -> offline mode
                self._client = None

    @property
    def available(self) -> bool:
        return self._client is not None

    def ask(self, system: str, prompt: str, image: np.ndarray | None = None,
            max_tokens: int = 900) -> str | None:
        if not self.available:
            return None
        content: list[dict] = []
        if image is not None:
            content.append({"type": "image", "source": {
                "type": "base64", "media_type": "image/png", "data": png_b64(image)}})
        content.append({"type": "text", "text": prompt})
        try:
            msg = self._client.messages.create(
                model=self.model, max_tokens=max_tokens, system=system,
                messages=[{"role": "user", "content": content}],
            )
            return "".join(b.text for b in msg.content if getattr(b, "type", "") == "text").strip()
        except Exception as exc:        # network/API errors degrade gracefully
            return f"[LLM unavailable: {type(exc).__name__}]"


def png_b64(img: np.ndarray) -> str:
    from PIL import Image
    arr = (np.clip(img, 0, 1) * 255).astype(np.uint8)
    buf = io.BytesIO()
    Image.fromarray(arr).save(buf, format="PNG")
    return base64.b64encode(buf.getvalue()).decode()
