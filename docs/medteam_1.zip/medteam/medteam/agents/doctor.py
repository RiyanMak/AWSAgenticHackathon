"""Doctor persona: integrates the Lab Analyst and Radiologist reports into a
diagnosis list, triage level, draft prescriptions (with safety checks),
tests, referrals and follow-up.

Prescribing logic is a small, transparent rule set loosely modelled on
common guideline defaults (ADA/KDIGO for diabetes+CKD, ACC/AHA for lipids,
ESC/AHA for AF, IDSA/ATS for community-acquired pneumonia). It is a teaching
scaffold: every prescription is a DRAFT for a licensed clinician.
"""
from __future__ import annotations

from ..models import AgentReport, CaseFile, Finding
from .base import Agent


def _sbp_dbp(bp: str | None) -> tuple[int, int] | None:
    try:
        s, d = (bp or "").split("/")
        return int(s), int(d)
    except ValueError:
        return None


def _has(lst: list[str], *words: str) -> bool:
    return any(w in item.lower() for item in lst for w in words)


class Doctor(Agent):
    name = "doctor"
    persona = "Doctor"
    voice = ("You are an experienced, kind family physician. You explain what each diagnosis "
             "means for daily life, why each medicine is chosen, and what happens next.")
    depends_on = ("lab_analyst", "radiologist")

    def analyze(self, case: CaseFile) -> AgentReport:
        p = case.patient
        rep = AgentReport(self.name, self.persona)
        codes = case.all_codes()
        lab_meas = case.reports["lab_analyst"].measurements if "lab_analyst" in case.reports else {}
        egfr = lab_meas.get("egfr")
        crcl = lab_meas.get("crcl_cockcroft_gault")
        L = case.lab
        v = p.vitals
        bp = _sbp_dbp(v.get("bp"))
        fever = (v.get("temp_c") or 0) >= 38.0 or _has(p.symptoms, "fever")
        cough = _has(p.symptoms, "cough")
        dx: list[dict] = []
        rx: list[dict] = []
        changes: list[dict] = []
        tests: list[str] = []
        referrals: list[str] = []
        red_flags: list[str] = []
        safety: list[str] = []
        scores: dict = {}
        current = [m.lower() for m in p.current_meds]
        allergies = [a.lower() for a in p.allergies]

        def add_dx(code, name, plain, certainty, evidence_codes, explain):
            ev = []
            for c in evidence_codes:
                f = case.finding(c)
                if f:
                    ev.append(f.label)
            dx.append(dict(code=code, name=name, plain_name=plain, certainty=certainty,
                           evidence=ev, explanation=explain))

        def prescribe(drug, dose, freq, duration, purpose, how, side_effects, checks):
            rx.append(dict(drug=drug, dose=dose, frequency=freq, duration=duration,
                           purpose=purpose, how_to_take=how, side_effects=side_effects,
                           safety_checks=checks))
            safety.extend(f"{drug}: {c}" for c in checks)

        # ------------------------------------------------------------------ #
        # Risk scores
        # ------------------------------------------------------------------ #
        has_htn = _has(p.history, "hypertension") or (bp and (bp[0] >= 140 or bp[1] >= 90))
        has_dm = _has(p.history, "diabetes") or "diabetes_new" in codes
        if "atrial_fibrillation" in codes:
            chf = _has(p.history, "heart failure")
            cha = (int(chf) + int(bool(has_htn)) + (2 if p.age >= 75 else 1 if p.age >= 65 else 0)
                   + int(has_dm) + (2 if _has(p.history, "stroke", "tia") else 0)
                   + int(_has(p.history, "myocardial", "peripheral arterial", "plaque"))
                   + int(p.sex == "F"))
            scores["CHA2DS2-VASc"] = cha
        if "focal_opacity" in codes:
            bun = L("bun") or 0
            curb = (int(_has(p.symptoms, "confus")) + int(bun > 19.6)       # urea > 7 mmol/L
                    + int((v.get("rr") or 0) >= 30)
                    + int(bool(bp) and (bp[0] < 90 or bp[1] <= 60)) + int(p.age >= 65))
            scores["CURB-65"] = curb

        # ------------------------------------------------------------------ #
        # Diagnoses + treatment
        # ------------------------------------------------------------------ #
        # --- Pneumonia --------------------------------------------------
        pneumonia = "focal_opacity" in codes and (fever or cough or "systemic_inflammation" in codes)
        if pneumonia:
            lobe = case.finding("focal_opacity").label.split(", ")[-1]
            add_dx("cap", f"Community-acquired pneumonia, {lobe}", "Chest infection (pneumonia)",
                   "likely", ["focal_opacity", "systemic_inflammation"],
                   "A bacterial infection in part of the lung. Most people recover fully with "
                   "antibiotics, rest and fluids over 1-3 weeks; tiredness and cough can last longer.")
            comorbid = (has_dm or "ckd" in codes or "atrial_fibrillation" in codes
                        or _has(p.history, "heart", "copd", "liver", "cancer"))
            if _has(allergies, "penicillin"):
                lev_dose = "750 mg" if (crcl or 99) >= 50 else "750 mg every 48 h"
                prescribe("Levofloxacin", lev_dose, "once daily", "5 days",
                          "Antibiotic to treat the lung infection",
                          "Take at the same time each day with water. Keep 2 hours apart from "
                          "iron, calcium, magnesium supplements and antacids.",
                          "Upset stomach, dizziness; rarely tendon pain (stop and call), "
                          "blood sugar swings.",
                          ["penicillin allergy -> beta-lactam avoided, respiratory fluoroquinolone chosen",
                           f"CrCl {crcl} mL/min -> {'no renal adjustment' if (crcl or 99) >= 50 else 'interval extended'}",
                           "QT prolongation risk noted: obtain 12-lead ECG QTc before first dose"])
            elif comorbid:
                prescribe("Amoxicillin-clavulanate", "875/125 mg", "twice daily", "5 days",
                          "Antibiotic for the lung infection", "Take with food.",
                          "Diarrhoea, nausea, rash (stop and call if rash).",
                          ["no penicillin allergy recorded", "comorbidity -> combination therapy"])
                prescribe("Doxycycline", "100 mg", "twice daily", "5 days",
                          "Second antibiotic covering atypical bacteria",
                          "Take upright with a full glass of water; avoid lying down for 30 min. "
                          "Keep 2 h apart from iron/calcium/antacids.",
                          "Heartburn, sun sensitivity.",
                          ["doxycycline preferred over macrolide (fewer QT/CYP3A4 interactions)"])
            else:
                prescribe("Amoxicillin", "1 g", "three times daily", "5 days",
                          "Antibiotic for the lung infection", "Take with or without food.",
                          "Diarrhoea, rash.", ["healthy adult without comorbidity"])
            prescribe("Acetaminophen (paracetamol)", "500-1000 mg", "every 6 hours if needed",
                      "while fever/aches last", "Fever and aches",
                      "Do not exceed 3,000 mg in 24 hours. Check other medicines for hidden acetaminophen.",
                      "Rare at normal doses.",
                      ["NSAIDs avoided" + (" (anticoagulant planned)" if "atrial_fibrillation" in codes else "")
                       + (" (kidney disease)" if "ckd" in codes else "")])
            tests += ["Repeat chest X-ray in 6-8 weeks if over 50 or smoker, to confirm clearing",
                      "Pulse oximetry at review"]
            spo2 = v.get("spo2") or 100
            if scores.get("CURB-65", 0) >= 2 or spo2 < 92:
                red_flags.append("CURB-65 >= 2 or SpO2 < 92%: hospital assessment advised")
            red_flags += ["Breathing becomes hard or lips turn blue", "Confusion or drowsiness",
                          "Fever not improving after 48-72 hours of antibiotics"]

        # --- Atrial fibrillation -----------------------------------------
        if "atrial_fibrillation" in codes:
            hr = lab_meas.get("ekg", {}).get("heart_rate_bpm", 0)
            add_dx("af", "Atrial fibrillation" + (" with rapid ventricular response" if hr > 100 else ""),
                   "Atrial fibrillation (irregular heartbeat)", "likely (confirm on 12-lead ECG)",
                   ["atrial_fibrillation"],
                   "The heart's upper chambers beat chaotically. The two goals are to keep the heart "
                   "rate comfortable and to prevent blood clots that can cause a stroke."
                   + (" A chest infection can trigger AF; it may settle as the infection clears." if pneumonia else ""))
            if hr > 110:
                if _has(p.history, "asthma", "copd"):
                    prescribe("Diltiazem ER", "120 mg", "once daily", "ongoing, review in 2 weeks",
                              "Slows the heart rate", "Swallow whole.", "Ankle swelling, dizziness.",
                              ["beta-blocker avoided due to airway disease", "check echo before long-term use"])
                else:
                    prescribe("Metoprolol succinate", "25 mg", "once daily", "ongoing, review in 1-2 weeks",
                              "Slows the heart rate so it pumps more efficiently",
                              "Swallow whole; do not stop suddenly.",
                              "Tiredness, dizziness, cold hands.",
                              [f"resting HR {hr:.0f} > 110 -> rate control indicated",
                               "low starting dose; titrate to resting HR < 110"])
            cha = scores["CHA2DS2-VASc"]
            threshold = 3 if p.sex == "F" else 2
            if cha >= threshold:
                scr = L("creatinine") or 0
                reduce = sum([p.age >= 80, p.weight_kg <= 60, scr >= 1.5])
                if (crcl or 99) < 15:
                    safety.append("Apixaban: CrCl < 15, anticoagulant choice needs specialist input")
                    referrals.append("Cardiology/nephrology: anticoagulation with severe kidney impairment")
                else:
                    prescribe("Apixaban", "2.5 mg" if reduce >= 2 else "5 mg", "twice daily", "long-term",
                              "Thins the blood to lower stroke risk from AF",
                              "Take every 12 hours; don't skip doses. Tell any dentist or surgeon you take it.",
                              "Easier bruising; seek help for black stools, blood in urine or vomit.",
                              [f"CHA2DS2-VASc {cha} (threshold {threshold}) -> anticoagulation indicated",
                               f"dose-reduction criteria met: {reduce}/3 -> {'2.5' if reduce >= 2 else '5'} mg",
                               "no strong CYP3A4/P-gp inhibitor prescribed (clarithromycin avoided)",
                               "NSAIDs and aspirin to be avoided"])
            tests += ["12-lead ECG to confirm AF", "Echocardiogram"]
            if L("tsh") is None:
                tests.append("TSH (thyroid can trigger AF)")
            referrals.append("Cardiology (AF clinic) within 2-4 weeks")
            red_flags += ["Chest pain or fainting", "Sudden weakness, face drooping or speech trouble (call 911)",
                          "Heart racing with breathlessness at rest"]

        # --- Diabetes ----------------------------------------------------
        dm_codes = {"diabetes_new", "diabetes_above_target", "diabetes_at_target"} & codes
        if dm_codes:
            a1c = L("hba1c")
            new = "diabetes_new" in codes
            add_dx("t2dm", "Type 2 diabetes mellitus" + (" (new diagnosis; confirm with repeat HbA1c)" if new
                   else f", HbA1c {a1c}% {'above' if a1c > 7 else 'at'} target"),
                   "Type 2 diabetes", "likely" if new else "confirmed", list(dm_codes),
                   "Your body isn't using insulin well, so sugar builds up in the blood. Over years "
                   "high sugar can damage eyes, kidneys, nerves and blood vessels. Medicine, food and "
                   "activity together bring it down.")
            on_met = any("metformin" in m for m in current)
            if egfr is not None:
                if on_met and egfr < 30:
                    changes.append(dict(drug="Metformin", action="STOP",
                                        reason=f"eGFR {egfr:.0f} < 30: risk of lactic acidosis"))
                elif on_met and egfr < 45:
                    changes.append(dict(drug="Metformin", action="REDUCE to 500 mg twice daily (max 1,000 mg/day)",
                                        reason=f"eGFR {egfr:.0f} (30-44): dose limit for kidney safety"))
                    safety.append(f"Metformin: current dose exceeds limit for eGFR {egfr:.0f}; reduced")
                elif not on_met and egfr >= 45 and a1c and a1c >= 6.5:
                    prescribe("Metformin", "500 mg", "once daily with evening meal for 1 week, then "
                              "increase by 500 mg weekly to 1,000 mg twice daily", "long-term",
                              "Lowers blood sugar", "Take with food to reduce stomach upset.",
                              "Upset stomach or loose stools at first (usually settles); low B12 over years.",
                              [f"eGFR {egfr:.0f} >= 45 -> full dose allowed",
                               "slow titration for GI tolerance", "hold on day of iodinated contrast"])
            if a1c and a1c >= 8 and p.bmi >= 30:
                safety.append("GLP-1 receptor agonist worth discussing for glucose + weight (clinician decision)")
            tests += ["Repeat HbA1c in 3 months", "Dilated eye exam", "Foot exam with monofilament"]

        # --- CKD ----------------------------------------------------------
        if "ckd" in codes:
            stage = lab_meas.get("ckd_stage", "")
            add_dx("ckd", f"Chronic kidney disease {stage}" + (" (diabetic kidney disease likely)" if dm_codes else ""),
                   "Chronic kidney disease", "likely (confirm persistence >= 3 months)", ["ckd"],
                   "Your kidneys are not filtering as well as they should. The aim is to protect what "
                   "kidney function you have: control sugar and blood pressure, and use medicines "
                   "that shield the kidneys.")
            if dm_codes and egfr and egfr >= 20:
                prescribe("Dapagliflozin", "10 mg", "once daily", "long-term",
                          "Protects the kidneys and heart; lowers sugar a little",
                          "Take in the morning. Drink normally. Pause it on days you're too sick to eat "
                          "or drink ('sick-day rule').",
                          "Genital yeast infection, needing to pass urine more; rare ketoacidosis.",
                          [f"eGFR {egfr:.0f} >= 20 -> kidney-protective indication",
                           "small expected eGFR dip after starting; recheck in 2-4 weeks"]
                          + (["started AFTER acute infection resolves"] if pneumonia else []))
            uacr = L("uacr") or 0
            on_raas = any(x in m for m in current for x in ("pril", "sartan"))
            if uacr >= 30 and not on_raas:
                k = L("potassium") or 0
                if k > 5.0:
                    changes.append(dict(drug="Losartan 25 mg daily (ARB)", action="DEFER",
                                        reason=f"Indicated for albuminuria, but K {k} > 5.0; start once K < 5.0"))
                    safety.append(f"ARB deferred: potassium {k}")
                else:
                    prescribe("Losartan", "25 mg", "once daily", "long-term",
                              "Lowers blood pressure and reduces protein leak from kidneys",
                              "Same time each day.", "Dizziness; can raise potassium.",
                              [f"uACR {uacr} >= 30 -> RAAS blockade", "recheck K and creatinine in 1-2 weeks"])
            elif on_raas:
                changes.append(dict(drug=next(m for m in p.current_meds if "pril" in m or "sartan" in m),
                                    action="CONTINUE", reason="Already protects the kidneys"))
            tests += ["Repeat creatinine/eGFR and uACR in 3 months", "Renal ultrasound"]
            if egfr and egfr < 45:
                referrals.append("Nephrology (eGFR < 45)")
            if any("ibuprofen" in m or "naproxen" in m for m in current):
                changes.append(dict(drug="NSAID", action="STOP", reason="Harms the kidneys"))

        # --- Hyperkalaemia ----------------------------------------------
        if "hyperkalemia" in codes:
            k = L("potassium")
            add_dx("hyperk", f"Hyperkalaemia (K {k})", "High potassium", "confirmed", ["hyperkalemia"],
                   "Potassium is a bit high, likely from reduced kidney function. A lower-potassium diet "
                   "and a repeat blood test are the first steps.")
            tests.append("Repeat potassium within 1 week (non-haemolysed sample)")
            red_flags.append("Muscle weakness or palpitations with high potassium")

        # --- Hypertension ------------------------------------------------
        if has_htn and bp and (bp[0] >= 130 or bp[1] > 80):
            add_dx("htn", f"Hypertension, above target ({v['bp']})", "High blood pressure",
                   "confirmed" if _has(p.history, "hypertension") else "possible (confirm with home readings)",
                   [], "Blood pressure is above the target of 130/80, which strains heart and kidneys.")
            lis = next((m for m in p.current_meds if "lisinopril 10" in m.lower()), None)
            if lis and (L("potassium") or 0) <= 5.0:
                changes[:] = [c for c in changes if c["drug"] != lis]
                changes.append(dict(drug=lis, action="INCREASE to lisinopril 20 mg daily",
                                    reason=f"BP {v['bp']} above target; K {L('potassium')} allows it; "
                                           "recheck K/creatinine in 1-2 weeks"))
            tests.append("Home blood-pressure log for 1 week")

        # --- Lipids -------------------------------------------------------
        if "dyslipidemia" in codes or (dm_codes and 40 <= p.age <= 75):
            ldl = L("ldl")
            add_dx("lipids", f"Dyslipidaemia (LDL {ldl})" if "dyslipidemia" in codes else
                   "Raised cardiovascular risk (diabetes)", "High cholesterol / heart risk", "confirmed",
                   ["dyslipidemia"], "Extra cholesterol can build up in arteries. Lowering it cuts the "
                   "chance of heart attack and stroke.")
            on_statin = any("statin" in m for m in current)
            if not on_statin and (dm_codes and 40 <= p.age <= 75 or (ldl or 0) >= 190):
                enhancers = sum([bool(has_htn), "ckd" in codes, (ldl or 0) >= 160, (L("tg") or 0) >= 175])
                dose = "40 mg" if enhancers >= 2 else "20 mg"
                prescribe("Atorvastatin", dose, "once daily", "long-term",
                          "Lowers 'bad' cholesterol and protects arteries",
                          "Any time of day, same time daily.", "Muscle aches (tell your doctor).",
                          [f"diabetes age 40-75 -> statin indicated; {enhancers} risk enhancers -> {dose}",
                           f"ALT {L('alt')} < 3x upper limit -> safe to start" if L("alt") else "baseline ALT advised",
                           "no interacting drugs (e.g. clarithromycin) prescribed"])
                tests.append("Lipid panel 6-12 weeks after starting statin")
            elif not on_statin:
                tests.append("10-year cardiovascular risk calculation (PREVENT) to decide on a statin")

        # --- Anaemia ------------------------------------------------------
        anemia = next((c for c in codes if c.startswith("anemia_")), None)
        if anemia:
            hb = L("hemoglobin")
            ida = "iron_deficiency" in codes
            add_dx("ida" if ida else "anemia",
                   f"{'Iron-deficiency' if ida else anemia.split('_')[1].capitalize()} anaemia (Hb {hb})",
                   "Anaemia (low red blood cells)", "confirmed", [anemia, "iron_deficiency"],
                   "Your blood carries less oxygen than normal, which explains tiredness and breathlessness. "
                   + ("Low iron is the cause; we also need to find out why iron is low." if ida else ""))
            if ida:
                prescribe("Ferrous sulfate", "325 mg (65 mg iron)", "once every other day", "3 months, then recheck",
                          "Rebuilds iron stores and red blood cells",
                          "Take on an empty stomach with orange juice or vitamin C; not with tea, coffee, "
                          "milk or calcium. Keep 2 h apart from antibiotics like levofloxacin/doxycycline.",
                          "Dark stools (harmless), constipation, stomach upset.",
                          ["alternate-day dosing improves absorption and tolerance"]
                          + (["CKD: if no response in 1-3 months consider IV iron"] if "ckd" in codes else []))
                if p.age >= 50:
                    referrals.append("Gastroenterology: upper endoscopy + colonoscopy to look for blood loss")
                tests += ["CBC and ferritin in 4-8 weeks", "Celiac serology", "Stool/urine check for blood"]
            if hb and hb < 8:
                red_flags.append("Hb < 8: consider urgent review / transfusion assessment")

        # --- Heart failure suspicion -------------------------------------
        hf_signals = {"cardiomegaly", "elevated_ntprobnp"} & codes
        if hf_signals and _has(p.symptoms, "breath", "swelling"):
            confounders = [c for c, ok in (("anaemia", bool(anemia)), ("kidney disease", "ckd" in codes),
                                           ("atrial fibrillation", "atrial_fibrillation" in codes),
                                           ("the chest infection", pneumonia)) if ok]
            add_dx("hf_suspected", "Suspected heart failure (needs echocardiogram)",
                   "Possible heart weakness or strain", "possible", list(hf_signals),
                   "Some tests suggest your heart may be working harder than it should. An ultrasound of "
                   "the heart (echo) will show whether this is heart failure."
                   + (f" {' and '.join(confounders).capitalize()} can also cause these results."
                      if confounders else ""))
            if not any(t.startswith("Echocardiogram") for t in tests):
                tests.append("Echocardiogram (within 2 weeks)")
            if not any(r.startswith("Cardiology") for r in referrals):
                referrals.append("Cardiology")
            red_flags += ["Breathless lying flat or waking up gasping", "Weight gain > 2 kg in 3 days"]
        elif "cardiomegaly" in codes and not hf_signals - {"cardiomegaly"}:
            tests.append("Echocardiogram to assess heart size")

        # --- Liver --------------------------------------------------------
        if "elevated_alt" in codes and (p.bmi >= 30 or dm_codes):
            add_dx("masld", "Possible metabolic dysfunction-associated fatty liver (MASLD)",
                   "Possible fatty liver", "possible", ["elevated_alt"],
                   "Extra fat may be stored in the liver. Losing 7-10% of body weight often reverses it.")
            tests += ["Liver ultrasound", "FIB-4 score"]

        # --- Obesity ------------------------------------------------------
        if p.bmi >= 30:
            add_dx("obesity", f"Obesity (BMI {p.bmi})", "Weight above a healthy range", "confirmed", [],
                   "Losing even 5-10% of body weight improves sugar, blood pressure, cholesterol and the liver.")

        # --- Vitamins -----------------------------------------------------
        if "vitamin_d_low" in codes:
            vd = L("vitamin_d")
            prescribe("Cholecalciferol (vitamin D3)", "2,000 IU" if vd < 20 else "1,000 IU", "once daily",
                      "3 months, then recheck", "Restores vitamin D for bones and muscles",
                      "Take with a meal that has some fat.", "Very rare at this dose.",
                      [f"25-OH D {vd} ng/mL"])
        if "b12_borderline" in codes:
            tests.append("Methylmalonic acid to confirm B12 status")
            prescribe("Vitamin B12 (cyanocobalamin)", "1,000 mcg", "once daily", "3 months",
                      "Tops up vitamin B12 (lowered by long-term metformin)", "Any time.", "None common.",
                      [f"B12 {L('b12')} pg/mL on metformin"])

        # --- Sinus tachycardia explanation ---------------------------------
        if "sinus_tachycardia" in codes:
            causes = [c for c, ok in (("anaemia", bool(anemia)), ("fever", fever),
                                      ("possible heart strain", bool(hf_signals))) if ok]
            add_dx("sinus_tachy", "Sinus tachycardia" + (f", likely secondary to {', '.join(causes)}" if causes else ""),
                   "Fast but regular heartbeat", "confirmed", ["sinus_tachycardia"],
                   "Your heart is beating fast to make up for " + (" and ".join(causes) if causes else
                   "something else") + ". Treating the cause should slow it.")

        # --- Critical labs override ---------------------------------------
        crit = [c for c in codes if c.startswith("critical_")]
        # ------------------------------------------------------------------ #
        # Triage
        # ------------------------------------------------------------------ #
        if crit or (v.get("spo2") or 100) < 90 or scores.get("CURB-65", 0) >= 3:
            urgency = "EMERGENCY - go to the emergency department now"
        elif pneumonia or (("atrial_fibrillation" in codes) and lab_meas.get("ekg", {}).get("heart_rate_bpm", 0) > 110) \
                or scores.get("CURB-65", 0) >= 2:
            urgency = "SAME DAY - see a clinician in person today"
        elif hf_signals or "hyperkalemia" in codes or (anemia and (L("hemoglobin") or 99) < 10):
            urgency = "SOON - clinician review within 1 week"
        else:
            urgency = "ROUTINE - clinician review within 2-4 weeks"

        follow = ("48-72 hours (infection check), then 2 weeks" if pneumonia
                  else "1-2 weeks (blood tests), then 3 months" if {"ckd", "hyperkalemia"} & codes
                  else "4-6 weeks, then every 3 months")

        # Dedupe while preserving order.
        tests = list(dict.fromkeys(tests))
        referrals = list(dict.fromkeys(referrals))
        red_flags = list(dict.fromkeys(red_flags))

        rep.measurements.update(diagnoses=dx, urgency=urgency, risk_scores=scores,
                                tests=tests, referrals=referrals, red_flags=red_flags,
                                follow_up=follow, safety_log=safety, medication_changes=changes)
        rep.recommendations = rx
        rep.findings = [Finding(d["code"], d["name"], "moderate", d["evidence"], d["explanation"])
                        for d in dx]
        rep.warnings.append("All prescriptions are DRAFTS generated by software on synthetic data. "
                            "They must be reviewed and signed by a licensed clinician.")
        names = ", ".join(d["plain_name"].lower() for d in dx[:4])
        rep.patient_summary = (f"Putting all the results together, the main issues are: {names}. "
                               f"Recommended timing: {urgency.split(' - ')[1]}. "
                               f"I've drafted {len(rx)} medicine(s) and {len(changes)} change(s) to your "
                               "current medicines for your doctor to review.")
        return rep
