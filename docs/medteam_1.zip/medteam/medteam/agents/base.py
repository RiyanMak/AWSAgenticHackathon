from __future__ import annotations

import json

from ..llm import LLM
from ..models import AgentReport, CaseFile

SAFETY_RULES = (
    "You are part of an EDUCATIONAL multi-agent demo that runs only on synthetic or "
    "public de-identified data. Never invent findings that are not in the structured "
    "data you are given. Do not change any drug, dose or number. Write for a patient "
    "with no medical training (about a 6th-8th grade reading level), warm and calm, "
    "short sentences, no jargon without a plain explanation. Always remind the reader "
    "that a licensed clinician must review the plan."
)


class Agent:
    name = "agent"
    persona = "Generic agent"
    voice = ""              # persona style for the LLM
    depends_on: tuple[str, ...] = ()

    def __init__(self, llm: LLM | None = None):
        self.llm = llm or LLM(enabled=False)

    # Subclasses implement the deterministic analysis.
    def analyze(self, case: CaseFile) -> AgentReport:  # pragma: no cover
        raise NotImplementedError

    def run(self, case: CaseFile) -> AgentReport:
        case.log(f"[{self.persona}] starting")
        report = self.analyze(case)
        if self.llm.available:
            narrated = self.narrate(report)
            if narrated and not narrated.startswith("[LLM unavailable"):
                report.patient_summary = narrated
        case.reports[self.name] = report
        case.log(f"[{self.persona}] done: {len(report.findings)} findings, "
                 f"{len(report.recommendations)} recommendations")
        return report

    def narrate(self, report: AgentReport) -> str | None:
        payload = {
            "findings": [f.to_dict() for f in report.findings],
            "measurements": report.measurements,
            "recommendations": report.recommendations,
            "warnings": report.warnings,
            "draft_summary": report.patient_summary,
        }
        system = f"You are the {self.persona}. {self.voice} {SAFETY_RULES}"
        prompt = ("Rewrite the draft summary for the patient in 120-180 words using only "
                  "this structured data:\n" + json.dumps(payload, default=str, indent=1))
        return self.llm.ask(system, prompt)
