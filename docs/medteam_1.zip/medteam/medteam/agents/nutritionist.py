"""Nutritionist persona: energy targets, condition-specific diet rules,
food-drug interactions and a sample day of meals."""
from __future__ import annotations

from ..models import AgentReport, CaseFile, Finding
from .base import Agent

# Each option: (name, approx kcal, tags). Tags drive filtering and scoring.
#   veg = vegetarian ok, vegan = vegan ok, dairy = contains dairy
#   low_gi, high_fiber, iron, high_k (potassium-rich), low_na, soft, protein, omega3
MEALS = {
    "breakfast": [
        ("Steel-cut oats with walnuts, cinnamon and a few blueberries", 380, {"veg", "vegan", "low_gi", "high_fiber", "low_na"}),
        ("Iron-fortified bran flakes with soy milk and sliced strawberries", 330, {"veg", "vegan", "iron", "high_fiber", "low_na"}),
        ("Two-egg vegetable omelette (peppers, onion) with 1 slice whole-grain toast", 360, {"veg", "low_gi", "protein", "low_na"}),
        ("Greek yogurt with chia seeds and raspberries", 300, {"veg", "dairy", "low_gi", "protein", "high_fiber"}),
        ("Tofu scramble with turmeric, onion and a small whole-wheat pita", 340, {"veg", "vegan", "iron", "protein", "low_gi"}),
        ("Banana-spinach smoothie with peanut butter", 390, {"veg", "vegan", "high_k", "iron", "soft"}),
        ("Cream of wheat (iron-fortified) made with water, topped with apple slices", 280, {"veg", "vegan", "iron", "soft", "low_na"}),
    ],
    "lunch": [
        ("Lentil and vegetable soup with a side salad", 450, {"veg", "vegan", "iron", "high_fiber", "low_gi", "high_k", "soft"}),
        ("Grilled chicken, quinoa and roasted vegetable bowl with olive-oil dressing", 520, {"low_gi", "protein", "high_fiber"}),
        ("Chickpea salad wrap (whole-wheat) with cucumber, red pepper and lemon-tahini", 480, {"veg", "vegan", "iron", "high_fiber", "low_gi", "high_k"}),
        ("Tofu and cabbage stir-fry with white rice (rinsed), low-sodium sauce", 470, {"veg", "vegan", "iron", "protein", "low_na"}),
        ("Chicken and rice soup (low-sodium broth), soft-cooked carrots", 400, {"soft", "protein", "low_na"}),
        ("Tuna and white-bean salad on mixed greens", 450, {"protein", "omega3", "low_gi", "high_fiber", "iron"}),
        ("Egg-salad sandwich on white bread with cucumber and lettuce", 430, {"veg", "protein", "low_na"}),
    ],
    "dinner": [
        ("Baked salmon, green beans and 1/2 cup brown rice", 540, {"protein", "omega3", "low_gi", "low_na"}),
        ("Chicken breast, cauliflower mash and steamed broccoli", 480, {"protein", "low_gi", "low_na"}),
        ("Kidney-bean and spinach curry with brown rice", 560, {"veg", "vegan", "iron", "high_fiber", "high_k"}),
        ("Tofu, bell-pepper and green-bean stir-fry over white rice", 500, {"veg", "vegan", "iron", "protein", "low_na"}),
        ("Whole-wheat pasta with turkey-mince tomato sauce and side salad", 560, {"protein", "high_fiber", "iron"}),
        ("Vegetable and egg fried cauliflower-rice with peas", 420, {"veg", "low_gi", "protein", "low_na"}),
        ("Soft scrambled eggs, mashed sweet potato and stewed apples", 450, {"veg", "soft", "high_k"}),
    ],
    "snack": [
        ("Apple slices with 1 tbsp almond butter", 190, {"veg", "vegan", "low_gi", "high_fiber"}),
        ("A small handful of unsalted almonds", 160, {"veg", "vegan", "low_gi", "low_na"}),
        ("Carrot and cucumber sticks with hummus", 150, {"veg", "vegan", "high_fiber", "iron", "high_k"}),
        ("Plain yogurt with cinnamon", 140, {"veg", "dairy", "protein", "soft"}),
        ("Rice cakes with a little cream cheese and blueberries", 160, {"veg", "dairy", "low_na"}),
        ("Pumpkin seeds (unsalted), small handful", 170, {"veg", "vegan", "iron", "low_na"}),
        ("Banana", 105, {"veg", "vegan", "high_k", "soft"}),
    ],
}

# Priorities when several goals compete (e.g. iron repletion beats fibre).
WEIGHTS = {"iron": 4, "soft": 3, "low_gi": 2, "low_na": 2, "high_fiber": 2, "omega3": 2}

ACTIVITY = {"sedentary": 1.2, "light": 1.375, "moderate": 1.55, "active": 1.725}


class Nutritionist(Agent):
    name = "nutritionist"
    persona = "Nutritionist"
    voice = ("You are an encouraging registered dietitian. You focus on practical swaps and "
             "foods to enjoy, not just foods to avoid.")
    depends_on = ("doctor",)

    def analyze(self, case: CaseFile) -> AgentReport:
        p = case.patient
        rep = AgentReport(self.name, self.persona)
        codes = case.all_codes()
        doc = case.reports.get("doctor")
        rx = doc.recommendations if doc else []
        rx_names = " ".join(r["drug"].lower() for r in rx)
        cur_meds = " ".join(p.current_meds).lower()
        all_meds = rx_names + " " + cur_meds

        # ---- Energy target (Mifflin-St Jeor) -----------------------------
        bmr = 10 * p.weight_kg + 6.25 * p.height_cm - 5 * p.age + (5 if p.sex == "M" else -161)
        tdee = bmr * ACTIVITY.get(p.activity_level, 1.375)
        acute = "cap" in codes or "systemic_inflammation" in codes
        if acute:
            target, goal = tdee, "maintain weight while recovering (illness raises energy needs)"
        elif p.bmi >= 27:
            floor = 1200 if p.sex == "F" else 1500
            target, goal = max(tdee - 500, floor), "gradual weight loss of about 0.5 kg (1 lb) per week"
        elif p.bmi < 18.5:
            target, goal = tdee + 300, "gentle weight gain"
        else:
            target, goal = tdee, "maintain weight"
        target = round(target / 50) * 50

        # ---- Rules ------------------------------------------------------
        rules: list[dict] = []
        want, avoid = set(), set()
        diabetic = bool({"t2dm", "diabetes_new", "diabetes_above_target", "diabetes_at_target", "prediabetes"} & codes)
        ckd = "ckd" in codes
        hyperk = "hyperkalemia" in codes
        egfr = case.reports["lab_analyst"].measurements.get("egfr") if "lab_analyst" in case.reports else None

        fat_pct, prot_gkg = 30, 1.0
        if diabetic:
            fat_pct = 35          # carbs fall to ~40-45% of energy
            want |= {"low_gi", "high_fiber"}
            rules.append(dict(topic="Blood sugar",
                advice="Fill half the plate with non-starchy vegetables, a quarter with protein, a quarter "
                       "with whole grains. Spread carbs evenly over 3 meals. Swap sugary drinks for water.",
                why="Steady carbs avoid sugar spikes; fibre slows sugar absorption."))
        if "dyslipidemia" in codes or "lipids" in codes:
            want |= {"omega3", "high_fiber"}
            rules.append(dict(topic="Cholesterol",
                advice="Use olive oil instead of butter, eat oily fish twice a week (or walnuts/flax if "
                       "vegetarian), aim for 25-30 g fibre a day (oats, beans, vegetables). Limit fried foods, "
                       "pastries and processed meats.",
                why="Soluble fibre and unsaturated fats lower LDL and triglycerides."))
        if ckd:
            prot_gkg = 0.8
            want.add("low_na")
            rules.append(dict(topic="Kidneys",
                advice=f"Keep protein moderate (about {round(0.8 * p.weight_kg)} g a day), favour plant "
                       "proteins, keep salt under 2 g sodium (about 1 teaspoon of salt) a day. Avoid salt "
                       "substitutes - they are made of potassium.",
                why="Moderate protein and less salt reduce strain on the kidneys and help blood pressure."))
        if hyperk:
            avoid.add("high_k")
            want.add("low_k")
            rules.append(dict(topic="Potassium",
                advice="For now limit bananas, oranges, potatoes, tomatoes, spinach, beans and dried fruit. "
                       "Choose apples, berries, grapes, cabbage, green beans, peppers, white rice. Soaking and "
                       "boiling vegetables (then discarding the water) removes some potassium.",
                why="Your potassium is a little high; less from food is the first fix."))
        if {"htn"} & codes or ckd or "hf_suspected" in codes:
            want.add("low_na")
            rules.append(dict(topic="Salt",
                advice="Cook from scratch, taste before salting, use herbs, lemon, garlic and spices. "
                       "Check labels: under 400 mg sodium per serving is a good rule.",
                why="Less salt lowers blood pressure and fluid build-up."))
        if "iron_deficiency" in codes or "ida" in codes:
            want.add("iron")
            plant = p.diet_preference in ("vegetarian", "vegan")
            src = ("iron-fortified cereals, tofu, pumpkin seeds, chickpeas and eggs"
                   if plant else "lean red meat 2-3 times a week, chicken, fish, eggs and fortified cereals")
            if hyperk:
                src += " (choosing lower-potassium iron sources while potassium is high)"
                rep.warnings.append("Conflict resolved: iron-rich spinach, lentils and beans are also "
                                    "potassium-rich, so lower-potassium iron sources were chosen.")
            rules.append(dict(topic="Iron",
                advice=f"Eat iron foods at every meal: {src}. Pair them with vitamin C (peppers, "
                       "strawberries, citrus). Keep tea and coffee at least 1 hour away from meals.",
                why="Vitamin C can double plant-iron absorption; tea and coffee block it."))
        if acute:
            want.add("soft")
            rules.append(dict(topic="While you're unwell",
                advice="Drink regularly - aim for pale yellow urine (about 2 L a day unless your doctor "
                       "limits fluids). Small, soft, frequent meals are fine if your appetite is low. "
                       "Soups, eggs, yogurt and fruit are good choices.",
                why="Fever and fast breathing increase fluid loss."))
        if "masld" in codes:
            rules.append(dict(topic="Liver", advice="Avoid alcohol and sugary drinks; weight loss of 7-10% "
                              "often reverses fatty liver.", why="Fructose and alcohol add liver fat."))
        if "vitamin_d_low" in codes:
            rules.append(dict(topic="Vitamin D", advice="Include oily fish, eggs and fortified milk; take "
                              "the vitamin D supplement with a meal.", why="Vitamin D is fat-soluble."))

        # ---- Food-drug interactions -------------------------------------
        inter = []
        if "levofloxacin" in all_meds or "doxycycline" in all_meds:
            inter.append("Antibiotic: keep dairy, calcium, iron and antacids at least 2 hours away from each dose.")
        if "ferrous" in all_meds:
            inter.append("Iron tablet: take with orange juice or vitamin C, not with tea, coffee, milk or calcium.")
        if "metformin" in all_meds:
            inter.append("Metformin: take with meals; it can lower vitamin B12 over years (eggs, dairy, fortified foods help).")
        if "atorvastatin" in all_meds or "apixaban" in all_meds:
            inter.append("Avoid large amounts of grapefruit or grapefruit juice (raises levels of "
                         + " and ".join(d for d in ("atorvastatin", "apixaban") if d in all_meds) + ").")
        if "dapagliflozin" in all_meds:
            inter.append("Dapagliflozin: stay well hydrated; on days you can't eat or drink, pause it (sick-day rule).")
        if any(x in all_meds for x in ("pril", "sartan")):
            inter.append("Blood-pressure medicine: do not use 'lite' salt or salt substitutes (they contain potassium).")
        if "apixaban" in all_meds:
            inter.append("Apixaban: no need to restrict vitamin K foods (unlike warfarin); avoid heavy alcohol.")

        # ---- Macros -------------------------------------------------------
        protein_g = round(prot_gkg * p.weight_kg)
        fat_g = round(target * fat_pct / 100 / 9)
        carb_g = round((target - protein_g * 4 - fat_g * 9) / 4)
        macros = dict(calories=int(target), protein_g=protein_g, carbs_g=carb_g, fat_g=fat_g,
                      fibre_g=30 if p.sex == "M" else 25, sodium_mg_max=2000 if "low_na" in want else 2300)

        plan = self._pick_meals(p.diet_preference, want, avoid, target)

        rep.measurements.update(bmr=round(bmr), tdee=round(tdee), goal=goal, macros=macros,
                                rules=rules, interactions=inter, meal_plan=plan)
        rep.findings.append(Finding("nutrition_plan", f"{int(target)} kcal/day, {goal}", "normal",
                                    [f"BMR {round(bmr)} kcal (Mifflin-St Jeor)", f"activity {p.activity_level}"]))
        rep.patient_summary = (f"Your eating plan aims for about {int(target)} calories a day to {goal}. "
                               + " ".join(r["advice"].split(".")[0] + "." for r in rules[:3]))
        return rep

    @staticmethod
    def _pick_meals(pref: str, want: set, avoid: set, target: float) -> list[dict]:
        plan = []
        budget = {"breakfast": 0.25, "lunch": 0.32, "dinner": 0.33, "snack": 0.10}
        for slot, opts in MEALS.items():
            scored = []
            for name, kcal, tags in opts:
                if pref == "vegan" and "vegan" not in tags:
                    continue
                if pref == "vegetarian" and "veg" not in tags:
                    continue
                if tags & avoid:
                    continue
                score = sum(WEIGHTS.get(t, 2) for t in tags & want) - abs(kcal - target * budget[slot]) / 150
                scored.append((score, name, kcal, tags))
            scored.sort(reverse=True)
            best = scored[0]
            alt = scored[1] if len(scored) > 1 else None
            plan.append(dict(meal=slot, choice=best[1], kcal=best[2],
                             why=", ".join(sorted(t.replace("_", " ") for t in best[3] & want)) or "balanced",
                             swap=alt[1] if alt else None))
        return plan
