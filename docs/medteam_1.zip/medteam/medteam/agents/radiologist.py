"""Radiologist persona: reads the chest radiograph."""
from __future__ import annotations

from ..image_tools import analyze_cxr
from ..models import AgentReport, CaseFile, Finding
from .base import SAFETY_RULES, Agent

ZONE_LOBE = {("right", "upper"): "right upper lobe", ("right", "middle"): "right middle lobe",
             ("right", "lower"): "right lower lobe", ("left", "upper"): "left upper lobe",
             ("left", "middle"): "lingula", ("left", "lower"): "left lower lobe"}


class Radiologist(Agent):
    name = "radiologist"
    persona = "Radiologist"
    voice = ("You are a calm, precise consultant radiologist who describes what is and is "
             "not seen, and always states the limits of a single image.")

    def analyze(self, case: CaseFile) -> AgentReport:
        rep = AgentReport(self.name, self.persona)
        if case.image is None:
            rep.warnings.append("No image supplied.")
            rep.patient_summary = "No X-ray was provided, so I had nothing to review."
            return rep

        res = analyze_cxr(case.image)
        rep.measurements["cxr"] = {k: v for k, v in res.items() if not k.startswith("_")}
        rep.measurements["_cxr_masks"] = res.get("_masks")
        if res["quality"] != "ok":
            rep.warnings.append(res["note"] + " Defer to a human radiologist.")
            rep.patient_summary = ("I could not read this image reliably, so a radiologist "
                                   "needs to review it directly.")
            return rep

        ctr = res["cardiothoracic_ratio"]
        impression = []
        if ctr > 0.5:
            sev = "moderate" if ctr > 0.55 else "mild"
            rep.findings.append(Finding("cardiomegaly", f"Enlarged cardiac silhouette (CTR {ctr})",
                sev, [f"cardiothoracic ratio {ctr} (normal <= 0.50 on PA)"],
                "Your heart's outline looks larger than usual on the X-ray. This can happen when "
                "the heart is working harder than normal. An ultrasound of the heart (echo) "
                "will show whether it is truly enlarged.", 0.75))
            impression.append(f"cardiomegaly (CTR {ctr})")
        for op in res["opacities"]:
            lobe = ZONE_LOBE[(op["side"], op["zone"])]
            rep.findings.append(Finding("focal_opacity", f"Focal airspace opacity, {lobe}",
                "moderate", [f"{op['side']} {op['zone']} zone density +{op['density_excess']} vs "
                             f"contralateral"],
                f"There is a cloudy patch in the {op['zone']} part of your {op['side']} lung. "
                "Together with fever and cough, this usually means a chest infection (pneumonia).",
                0.75))
            impression.append(f"focal opacity {lobe}")
        if not rep.findings:
            rep.findings.append(Finding("cxr_normal", "No acute cardiopulmonary abnormality", "normal",
                [f"CTR {ctr}", "symmetric lung fields"],
                "Your chest X-ray looks normal: the heart is a normal size and the lungs are clear.",
                0.75))
            impression.append("no acute abnormality")
        rep.measurements["impression"] = "; ".join(impression)
        rep.warnings.append("Automated heuristic read; must be confirmed by a radiologist.")

        # Optional second read by a vision model, kept separate from structured findings.
        if self.llm.available:
            second = self.llm.ask(
                f"You are a consultant radiologist. {SAFETY_RULES}",
                "This is a PA chest radiograph (may be synthetic). In <=80 words, give a "
                "radiologist-style impression. Then state agreement or disagreement with this "
                f"automated read: {rep.measurements['impression']}.",
                image=res["_normalised"])
            if second:
                rep.measurements["vision_second_read"] = second

        rep.patient_summary = " ".join(f.plain_language for f in rep.findings)
        return rep
