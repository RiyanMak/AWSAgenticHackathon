"""Physiotherapist persona: safe, graded exercise prescription (FITT) that
respects every other agent's findings."""
from __future__ import annotations

from ..models import AgentReport, CaseFile, Finding
from .base import Agent

DAYS = ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"]


class Physiotherapist(Agent):
    name = "physio"
    persona = "Physiotherapist"
    voice = ("You are an upbeat physiotherapist. You give concrete, doable steps, praise small "
             "wins and are very clear about when to stop.")
    depends_on = ("doctor",)

    def analyze(self, case: CaseFile) -> AgentReport:
        p = case.patient
        rep = AgentReport(self.name, self.persona)
        codes = case.all_codes()
        L = case.lab
        hr_rest = case.reports.get("lab_analyst").measurements.get("ekg", {}).get("heart_rate_bpm") \
            if "lab_analyst" in case.reports else p.vitals.get("hr")
        hr_rest = hr_rest or p.vitals.get("hr") or 75
        new_rx = case.reports["doctor"].recommendations if "doctor" in case.reports else []
        meds = (" ".join(p.current_meds) + " " + " ".join(r["drug"] for r in new_rx)).lower()

        # ---- Readiness gates (most restrictive wins) ---------------------
        holds: list[str] = []
        caps: list[str] = []
        intensity = "moderate"
        if any(c.startswith("critical_") for c in codes):
            holds.append("A critical lab value needs medical review before any exercise.")
            intensity = "none"
        if "cap" in codes or ((p.vitals.get("temp_c") or 0) >= 38):
            holds.append("Active chest infection/fever: no structured exercise until fever-free for 48-72 h "
                         "and breathing is comfortable. Gentle breathing exercises and short walks indoors only.")
            intensity = "recovery" if intensity != "none" else intensity
        if "atrial_fibrillation" in codes and hr_rest > 110:
            caps.append(f"Resting heart rate {hr_rest:.0f}: keep to light activity until the heart rate is "
                        "controlled (resting < 100-110).")
            intensity = "light" if intensity == "moderate" else intensity
        if "hf_suspected" in codes:
            caps.append("Possible heart strain: light activity only until the echo is done; avoid heavy lifting "
                        "and breath-holding.")
            intensity = "light" if intensity == "moderate" else intensity
        hb = L("hemoglobin")
        if hb is not None and hb < 8:
            holds.append(f"Haemoglobin {hb}: wait for medical review before exercising.")
            intensity = "none"
        elif hb is not None and hb < 10:
            caps.append(f"Haemoglobin {hb}: keep effort light (you can talk in full sentences); rest when breathless.")
            intensity = "light" if intensity == "moderate" else intensity
        if "hyperkalemia" in codes and (L("potassium") or 0) >= 6:
            holds.append("Potassium too high for exercise until treated.")
            intensity = "none"

        # Heart-rate guidance: beta-blockers and AF make HR targets unreliable -> use RPE.
        use_rpe = ("metoprolol" in meds or "atrial_fibrillation" in codes or "diltiazem" in meds
                   or hr_rest > 100)      # high resting HR (anaemia, fever) makes HR zones misleading
        hr_max = 208 - 0.7 * p.age
        hrr = hr_max - hr_rest
        zone = {"light": (0.30, 0.39), "moderate": (0.40, 0.59), "recovery": (0.2, 0.3)}.get(intensity)
        hr_zone = None
        if zone and not use_rpe:
            hr_zone = (round(hr_rest + zone[0] * hrr), round(hr_rest + zone[1] * hrr))
        rpe = {"recovery": "9-10 (very light)", "light": "10-11 (light)", "moderate": "12-13 (somewhat hard)",
               "none": "-"}[intensity]
        talk = {"recovery": "You can sing.", "light": "You can talk easily.",
                "moderate": "You can talk but not sing.", "none": "-"}[intensity]

        # ---- Program components ------------------------------------------
        older = p.age >= 65
        obese = p.bmi >= 30
        diabetic = bool({"t2dm"} & codes)
        aerobic_mode = ("brisk walking, stationary cycling or water walking (low impact on the joints)" if obese
                        else "brisk walking or cycling")
        if intensity == "none":
            phases = [dict(phase="Now", plan="Rest and medical review first. Light daily tasks only.")]
        elif intensity == "recovery":
            phases = [
                dict(phase="While unwell", plan="Breathing exercises 3x/day; sit out of bed and walk around the "
                     "house for 2-5 minutes every 1-2 hours while awake."),
                dict(phase="Fever-free 48-72 h", plan="Walks of 5-10 minutes once or twice daily, flat ground."),
                dict(phase="Weeks 2-4 after recovery", plan="Build to 20-30 minute walks, 5 days a week; "
                     "add the strength routine twice a week."),
            ]
        elif intensity == "light":
            phases = [
                dict(phase="Weeks 1-2", plan=f"10-15 min of {aerobic_mode}, 5 days/week, light effort."),
                dict(phase="Weeks 3-6", plan="Build to 20-30 min, 5 days/week; add 1 strength session/week."),
                dict(phase="After medical clearance", plan="Progress to moderate effort, 150 min/week."),
            ]
        else:
            phases = [
                dict(phase="Weeks 1-2", plan=f"15-20 min of {aerobic_mode}, 5 days/week + strength 2x/week."),
                dict(phase="Weeks 3-6", plan="25-30 min, 5 days/week (150 min/week) + strength 2-3x/week."),
                dict(phase="Week 7+", plan="Keep 150-300 min/week; add short faster intervals if comfortable."),
            ]

        strength = [
            ("Sit-to-stand from a chair", "2 sets x 8-12"),
            ("Wall push-ups", "2 sets x 8-12"),
            ("Standing calf raises (hold the counter)", "2 sets x 10-15"),
            ("Resistance-band rows", "2 sets x 10-12"),
            ("Glute bridge (on bed or floor)", "2 sets x 10"),
        ]
        if "hf_suspected" in codes or "atrial_fibrillation" in codes:
            strength = [(n, r.replace("2 sets", "1 set")) for n, r in strength]
        breathing = [("Pursed-lip breathing", "in through nose 2 counts, out through pursed lips 4 counts, 5 min"),
                     ("Deep breathing with 3-second hold, then a supported cough", "5 breaths, 3x/day")]
        balance = [("Heel-to-toe standing at the counter", "3 x 20 s"), ("Single-leg stand, hand on counter", "3 x 15 s each")]

        # ---- Weekly schedule ---------------------------------------------
        week = {}
        for i, d in enumerate(DAYS):
            items = []
            if intensity == "none":
                items = ["Rest"]
            elif intensity == "recovery":
                items = ["Breathing exercises 3x", "Short indoor walks every 1-2 h"]
            else:
                if i in (0, 1, 3, 4, 5):
                    items.append(f"Walk/cycle ({phases[0]['plan'].split(' of ')[0].split(',')[0]})")
                if i in (0, 3) or (intensity == "moderate" and i == 5):
                    items.append("Strength routine")
                if older and i in (1, 4):
                    items.append("Balance drills")
                if i == 6:
                    items.append("Rest or gentle stretching")
                if i == 2:
                    items.append("Stretching + rest day")
            week[d] = items

        # ---- Condition-specific safety notes -----------------------------
        notes = []
        if diabetic:
            notes.append("Check your feet daily and wear well-fitting shoes. Exercise after meals helps lower sugar.")
            if any(x in meds for x in ("insulin", "glipizide", "glyburide", "glimepiride")):
                notes.append("Your medicine can cause low sugar: check before exercise and carry glucose tablets.")
        if "apixaban" in meds:
            notes.append("You'll be on a blood thinner: avoid contact sports and activities with high fall risk.")
        if use_rpe:
            notes.append("Heart-rate targets aren't reliable for you right now (heart rhythm, medicine or a "
                         "fast resting rate), so use the effort scale and talk test instead.")
        if "ckd" in codes:
            notes.append("Stay hydrated during exercise unless your doctor has limited fluids.")
        if obese:
            notes.append("Low-impact options (cycling, pool) protect knees and hips while you build up.")

        stop_signs = ["Chest pain, pressure or tightness", "Severe breathlessness or wheezing that doesn't settle with rest",
                      "Dizziness, light-headedness or fainting", "Heart racing or pounding irregularly beyond your usual",
                      "Unusual sweating, nausea or confusion"]

        rep.measurements.update(
            intensity=intensity, holds=holds, caps=caps, rpe=rpe, talk_test=talk,
            hr_zone=hr_zone, use_rpe=use_rpe, phases=phases, strength=strength,
            breathing=breathing if ("cap" in codes or "hf_suspected" in codes) else [],
            balance=balance if older else [], week=week, notes=notes, stop_signs=stop_signs)
        rep.findings.append(Finding("exercise_plan", f"Exercise intensity: {intensity}", "normal",
                                    holds + caps or ["no restrictions identified"]))
        rep.patient_summary = (
            ("First, " + holds[0][0].lower() + holds[0][1:] + " " if holds else "")
            + f"For now your activity level is '{intensity}', about {rpe} on the effort scale "
              f"(talk test: {talk[0].lower() + talk[1:]}) "
            + (phases[0]["plan"] if phases else ""))
        return rep
