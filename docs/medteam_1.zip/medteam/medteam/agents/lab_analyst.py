"""Lab Analyst persona: interprets blood/urine chemistry and the EKG trace."""
from __future__ import annotations

from ..models import AgentReport, CaseFile, Finding
from ..reference import REFERENCE, bounds
from ..signal_tools import analyze_ekg
from .base import Agent


def egfr_ckd_epi_2021(scr: float, age: int, sex: str) -> float:
    """Race-free CKD-EPI 2021 creatinine equation (mL/min/1.73m2)."""
    k, a = (0.7, -0.241) if sex == "F" else (0.9, -0.302)
    ratio = scr / k
    e = 142 * min(ratio, 1) ** a * max(ratio, 1) ** -1.200 * 0.9938 ** age
    return round(e * (1.012 if sex == "F" else 1.0), 0)


def ckd_stage(egfr: float, uacr: float | None) -> tuple[str, str]:
    g = ("G1" if egfr >= 90 else "G2" if egfr >= 60 else "G3a" if egfr >= 45
         else "G3b" if egfr >= 30 else "G4" if egfr >= 15 else "G5")
    a = "" if uacr is None else ("A1" if uacr < 30 else "A2" if uacr <= 300 else "A3")
    return g, a


class LabAnalyst(Agent):
    name = "lab_analyst"
    persona = "Lab Analyst"
    voice = ("You are a meticulous clinical laboratory scientist who explains numbers "
             "with simple comparisons and never over-states certainty.")

    def analyze(self, case: CaseFile) -> AgentReport:
        p = case.patient
        rep = AgentReport(self.name, self.persona)
        table = []

        # ---- 1. Flag every value against its reference range ---------------
        for lv in case.labs:
            ref = REFERENCE.get(lv.test)
            if not ref:
                table.append(dict(test=lv.test, value=lv.value, unit=lv.unit, flag="?"))
                continue
            lo, hi = bounds(lv.test, p.sex)
            flag = "L" if lv.value < lo else "H" if lv.value > hi else ""
            if "crit_low" in ref and lv.value <= ref["crit_low"]:
                flag = "LL"
            if "crit_high" in ref and lv.value >= ref["crit_high"]:
                flag = "HH"
            table.append(dict(test=ref["name"], key=lv.test, value=lv.value, unit=ref["unit"],
                              range=f"{lo}-{hi}" if hi < 999 else f">{lo}", flag=flag,
                              plain=ref["plain"]))
            if flag in ("LL", "HH"):
                rep.findings.append(Finding(
                    f"critical_{lv.test}", f"CRITICAL {ref['name']} {lv.value} {ref['unit']}",
                    "critical", [f"{ref['name']} beyond critical limit"],
                    f"Your {ref['plain']} result is at a level that needs attention today.", 0.95))
        rep.measurements["lab_table"] = table

        L = case.lab
        # ---- 2. Pattern recognition across tests ---------------------------
        # Glycaemia
        a1c, glu = L("hba1c"), L("glucose")
        has_dm = any("diabetes" in h for h in p.history)
        if a1c is not None:
            if a1c >= 6.5 or (glu or 0) >= 126:
                sev = "severe" if a1c >= 10 else "moderate" if a1c >= 8 else "mild"
                if has_dm:
                    code, label = ("diabetes_above_target" if a1c > 7 else "diabetes_at_target",
                                   f"Known type 2 diabetes, HbA1c {a1c}%")
                    if a1c <= 7:
                        sev = "normal"
                else:
                    code, label = "diabetes_new", f"HbA1c {a1c}% / glucose {glu} mg/dL: meets diabetes criteria"
                rep.findings.append(Finding(code, label, sev,
                    [f"HbA1c {a1c}% (diabetes >= 6.5%)", f"fasting glucose {glu} mg/dL"],
                    f"Your average blood sugar over the last 3 months is {a1c}%. "
                    f"Below 5.7% is normal; 6.5% or higher means diabetes.", 0.9))
            elif a1c >= 5.7:
                rep.findings.append(Finding("prediabetes", f"Prediabetes (HbA1c {a1c}%)", "mild",
                    [f"HbA1c {a1c}% (5.7-6.4%)"],
                    "Your blood sugar is a little higher than ideal. This is called prediabetes "
                    "and can often be reversed with food and activity changes.", 0.85))

        # Lipids
        ldl, tg, hdl = L("ldl"), L("tg"), L("hdl")
        lip_ev = []
        if ldl and ldl >= 130: lip_ev.append(f"LDL {ldl} mg/dL")
        if tg and tg >= 150: lip_ev.append(f"triglycerides {tg} mg/dL")
        if hdl and hdl < bounds("hdl", p.sex)[0]: lip_ev.append(f"HDL {hdl} mg/dL (low)")
        if lip_ev:
            rep.findings.append(Finding("dyslipidemia", "Dyslipidaemia",
                "moderate" if (ldl or 0) >= 160 else "mild", lip_ev,
                "Your cholesterol and blood-fat levels are higher than recommended, which over "
                "years raises the risk of heart attack and stroke.", 0.9))

        # Kidney
        scr = L("creatinine")
        if scr:
            egfr = egfr_ckd_epi_2021(scr, p.age, p.sex)
            uacr = L("uacr")
            g, a = ckd_stage(egfr, uacr)
            crcl = round((140 - p.age) * p.weight_kg / (72 * scr) * (0.85 if p.sex == "F" else 1), 0)
            rep.measurements.update(egfr=egfr, ckd_stage=f"{g}{a}", crcl_cockcroft_gault=crcl)
            if egfr < 60 or (uacr is not None and uacr >= 30):
                sev = "moderate" if egfr < 45 or (uacr or 0) > 300 else "mild"
                rep.findings.append(Finding("ckd", f"Chronic kidney disease stage {g}{a} "
                    f"(eGFR {egfr:.0f}, uACR {uacr})", sev,
                    [f"eGFR {egfr:.0f} mL/min/1.73m2 (CKD-EPI 2021)", f"uACR {uacr} mg/g"],
                    f"Your kidneys are filtering at roughly {egfr:.0f}% of a healthy young adult's "
                    f"level{' and some protein is leaking into your urine' if (uacr or 0) >= 30 else ''}. "
                    "This needs to be confirmed with a repeat test in 3 months.", 0.8))

        # Electrolytes
        k = L("potassium")
        if k and k > 5.0:
            rep.findings.append(Finding("hyperkalemia", f"Hyperkalaemia K {k}",
                "moderate" if k >= 5.5 else "mild", [f"K {k} mmol/L"],
                "Your potassium is a little high. Too much potassium can affect the heart rhythm, "
                "so food and medicine choices need care.", 0.85))
        elif k and k < 3.5:
            rep.findings.append(Finding("hypokalemia", f"Hypokalaemia K {k}", "mild", [f"K {k}"],
                "Your potassium is a little low.", 0.85))

        # Blood count / iron
        hb, mcv, ferr = L("hemoglobin"), L("mcv"), L("ferritin")
        if hb and hb < bounds("hemoglobin", p.sex)[0]:
            kind = ("microcytic" if mcv and mcv < 80 else "macrocytic" if mcv and mcv > 100
                    else "normocytic")
            sev = "severe" if hb < 8 else "moderate" if hb < 10 else "mild"
            rep.findings.append(Finding(f"anemia_{kind}", f"{kind.capitalize()} anaemia, Hb {hb} g/dL",
                sev, [f"Hb {hb} g/dL", f"MCV {mcv} fL"],
                f"You have fewer healthy red blood cells than normal (anaemia). That can explain "
                "tiredness and breathlessness.", 0.9))
        ckd_present = any(f.code == "ckd" for f in rep.findings)
        if ferr is not None and (ferr < 30 or (ckd_present and ferr < 100 and hb and hb < 12)):
            rep.findings.append(Finding("iron_deficiency", f"Iron deficiency (ferritin {ferr})",
                "moderate" if ferr < 15 else "mild", [f"ferritin {ferr} ng/mL"],
                "Your body's iron stores are low. Iron is needed to make red blood cells.", 0.9))

        # Infection / inflammation
        wbc, crp = L("wbc"), L("crp")
        if wbc and crp and wbc > 11 and crp > 10:
            rep.findings.append(Finding("systemic_inflammation",
                f"Leukocytosis {wbc} with CRP {crp}: active infection/inflammation likely",
                "moderate" if crp < 150 else "severe", [f"WBC {wbc}", f"CRP {crp} mg/L"],
                "Your blood shows signs that your body is fighting an infection.", 0.85))

        # Liver
        alt = L("alt")
        if alt and alt > bounds("alt", p.sex)[1]:
            rep.findings.append(Finding("elevated_alt", f"Mildly raised ALT {alt} U/L",
                "mild" if alt < 3 * bounds("alt", p.sex)[1] else "moderate", [f"ALT {alt}"],
                "One liver test is slightly raised. This is common with extra weight around the "
                "middle and often improves with weight loss.", 0.7))

        # Vitamins
        vd = L("vitamin_d")
        if vd is not None and vd < 30:
            rep.findings.append(Finding("vitamin_d_low",
                f"Vitamin D {'deficiency' if vd < 20 else 'insufficiency'} ({vd} ng/mL)",
                "mild", [f"25-OH D {vd} ng/mL"], "Your vitamin D is low.", 0.9))
        b12 = L("b12")
        on_metformin = any("metformin" in m for m in p.current_meds)
        if b12 is not None and (b12 < 200 or (on_metformin and b12 < 300)):
            rep.findings.append(Finding("b12_borderline", f"Low/borderline B12 ({b12})", "mild",
                [f"B12 {b12} pg/mL"] + (["long-term metformin lowers B12"] if on_metformin else []),
                "Your vitamin B12 is on the low side.", 0.75))

        # Heart strain marker (age-adjusted rule-in for outpatients)
        bnp = L("nt_probnp")
        cutoff = 125 if p.age < 75 else 450
        if bnp is not None and bnp > cutoff:
            rep.findings.append(Finding("elevated_ntprobnp", f"Raised NT-proBNP {bnp} pg/mL",
                "moderate" if bnp > 4 * cutoff else "mild", [f"NT-proBNP {bnp} (> {cutoff})"],
                "A blood marker of heart strain is raised. It can rise with heart, kidney or "
                "rhythm problems, so your heart needs a closer look.", 0.75))

        tsh = L("tsh")
        if tsh is not None and not (0.4 <= tsh <= 4.5):
            rep.findings.append(Finding("thyroid_abnormal", f"TSH {tsh} out of range", "mild",
                [f"TSH {tsh}"], "Your thyroid test is outside the usual range.", 0.8))

        # ---- 3. EKG -------------------------------------------------------
        if case.ekg is not None:
            ek = analyze_ekg(case.ekg, case.ekg_fs)
            rep.measurements["ekg"] = {k: v for k, v in ek.items() if not k.startswith("_")}
            rep.measurements["_ekg_filtered"] = ek.get("_filtered")
            rep.measurements["_ekg_peaks"] = ek.get("_peaks")
            if ek.get("quality") == "poor":
                rep.warnings.append("EKG too noisy or short to analyse; repeat recording.")
            else:
                rep.findings.extend(self._ekg_findings(ek))

        n_abn = sum(1 for r in table if r.get("flag"))
        rep.patient_summary = (
            f"I checked {len(table)} blood and urine results; {n_abn} were outside the usual range. "
            + " ".join(f.plain_language for f in rep.findings if f.severity != "normal"))
        return rep

    @staticmethod
    def _ekg_findings(ek: dict) -> list[Finding]:
        hr, rhythm = ek["heart_rate_bpm"], ek["rhythm"]
        ev = [f"HR {hr:.0f} bpm", f"RR CV {ek['rr_cv']}", f"pNN50 {ek['pnn50']}",
              f"P waves in {ek['p_wave_fraction']:.0%} of beats"]
        out = []
        if rhythm == "atrial_fibrillation":
            out.append(Finding("atrial_fibrillation",
                f"Atrial fibrillation, {'rapid' if hr > 100 else 'controlled'} ventricular rate {hr:.0f}",
                "moderate" if hr > 110 else "mild", ev,
                "Your heartbeat is irregular in a pattern called atrial fibrillation (AF): the "
                "top chambers quiver instead of beating in step. AF is common and treatable, but it "
                "raises stroke risk, so it needs treatment.", 0.85))
        elif rhythm == "irregular_rhythm":
            out.append(Finding("irregular_rhythm", "Irregular rhythm with P waves (? ectopy)", "mild",
                ev, "Your heartbeat has some extra or skipped beats.", 0.6))
        elif rhythm == "sinus_tachycardia":
            out.append(Finding("sinus_tachycardia", f"Sinus tachycardia {hr:.0f} bpm", "mild", ev,
                f"Your heart rhythm is normal in pattern but fast ({hr:.0f} beats a minute at rest). "
                "This is usually a response to something else, such as anaemia, fever or dehydration.", 0.85))
        elif rhythm == "sinus_bradycardia":
            out.append(Finding("sinus_bradycardia", f"Sinus bradycardia {hr:.0f} bpm", "mild", ev,
                "Your heart rate is slow. This can be normal in fit people.", 0.8))
        else:
            out.append(Finding("normal_sinus_rhythm", f"Normal sinus rhythm {hr:.0f} bpm", "normal", ev,
                "Your heart rhythm tracing looks normal.", 0.85))
        if ek.get("qrs_ms") and ek["qrs_ms"] >= 120:
            out.append(Finding("wide_qrs", f"Wide QRS {ek['qrs_ms']:.0f} ms", "mild",
                [f"QRS {ek['qrs_ms']:.0f} ms"],
                "The electrical signal spreads through the heart more slowly than usual.", 0.6))
        return out
