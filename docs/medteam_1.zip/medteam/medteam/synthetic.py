"""Synthetic patient generator: labs, chest X-ray-like images and EKG lead II.

Everything here is fabricated from simple physical models so the pipeline can
be exercised end to end without any real patient data. Images are stylised
PA chest radiographs (not diagnostic quality); EKGs are Gaussian-sum
P-QRS-T templates with realistic noise, baseline wander and mains hum.
"""
from __future__ import annotations

import numpy as np
from scipy import ndimage

from .models import CaseFile, LabValue, Patient


# --------------------------------------------------------------------------- #
# EKG
# --------------------------------------------------------------------------- #
def synth_ekg(rhythm: str = "sinus", hr: float = 75, seconds: float = 10.0,
              fs: int = 250, qrs_ms: float = 90, seed: int = 0) -> np.ndarray:
    """Return a lead-II-like trace in millivolts.

    rhythm: "sinus" (regular, P waves present) or "af" (irregular RR,
    no P waves, fibrillatory baseline).
    """
    rng = np.random.default_rng(seed)
    n = int(seconds * fs)
    t = np.arange(n) / fs
    sig = np.zeros(n)

    mean_rr = 60.0 / hr
    beats, cur = [], 0.35
    while cur < seconds - 0.3:
        beats.append(cur)
        if rhythm == "af":
            rr = rng.lognormal(np.log(mean_rr), 0.24)          # highly irregular
            rr = float(np.clip(rr, 0.32, 1.6))
        else:
            rr = mean_rr * (1 + rng.normal(0, 0.025))           # mild sinus arrhythmia
        cur += rr

    qrs_s = qrs_ms / 1000
    qrs_sigma = qrs_s / 7
    for i, r in enumerate(beats):
        rr = beats[i + 1] - r if i + 1 < len(beats) else mean_rr
        waves = [  # (amplitude mV, offset s, width s)
            (-0.12, -0.31 * qrs_s, qrs_s / 10),   # Q
            (1.25, 0.0, qrs_sigma),          # R
            (-0.28, 0.33 * qrs_s, qrs_s / 9),     # S
            (0.32, 0.16 + 0.10 * np.sqrt(rr), 0.045),   # T
        ]
        if rhythm != "af":
            waves.append((0.15, -0.17, 0.022))          # P
        for amp, off, w in waves:
            sig += amp * np.exp(-0.5 * ((t - (r + off)) / w) ** 2)

    if rhythm == "af":   # fibrillatory "f waves" 5-7 Hz
        f = 6 + 0.8 * np.sin(2 * np.pi * 0.3 * t)
        sig += 0.05 * np.sin(2 * np.pi * np.cumsum(f) / fs)

    sig += 0.12 * np.sin(2 * np.pi * 0.18 * t + rng.uniform(0, 6))   # baseline wander
    sig += 0.015 * np.sin(2 * np.pi * 60 * t)                           # mains hum
    sig += rng.normal(0, 0.02, n)                                       # EMG/noise
    return sig


# --------------------------------------------------------------------------- #
# Chest X-ray (stylised)
# --------------------------------------------------------------------------- #
def _ellipse(shape, cy, cx, ry, rx):
    yy, xx = np.ogrid[:shape[0], :shape[1]]
    return ((yy - cy) / ry) ** 2 + ((xx - cx) / rx) ** 2 <= 1.0


def synth_cxr(size: int = 512, ctr: float = 0.45,
              opacity: tuple[str, str] | None = None,
              opacity_strength: float = 0.32, seed: int = 0) -> np.ndarray:
    """Stylised PA chest radiograph, grayscale 0..1 (bright = dense).

    ctr: target cardiothoracic ratio (heart width / internal thoracic width).
    opacity: e.g. ("right", "lower") - the PATIENT's side. In a PA view the
    patient's right lung is on the image's left.
    """
    rng = np.random.default_rng(seed)
    s = size
    img = np.full((s, s), 0.04)

    body = _ellipse((s, s), s * 0.55, s * 0.5, s * 0.52, s * 0.46)
    img[body] = 0.45

    lung_ry, lung_rx = s * 0.29, s * 0.155
    lung_cy = s * 0.47
    r_cx, l_cx = s * 0.5 - s * 0.19, s * 0.5 + s * 0.19     # patient R / L on image
    lung_r = _ellipse((s, s), lung_cy, r_cx, lung_ry, lung_rx)
    lung_l = _ellipse((s, s), lung_cy, l_cx, lung_ry, lung_rx)
    thorax_w = (l_cx + lung_rx) - (r_cx - lung_rx)

    # Heart: centred a little to the patient's left (image right).
    heart_w = ctr * thorax_w
    heart_cx = s * 0.5 + heart_w * 0.12
    heart = _ellipse((s, s), s * 0.62, heart_cx, s * 0.13, heart_w / 2)
    mediast = np.zeros_like(body)
    mediast[int(s * 0.12):int(s * 0.60), int(s * 0.5 - s * 0.045):int(s * 0.5 + s * 0.045)] = True

    lungs = (lung_r | lung_l) & ~heart & ~mediast
    img[lungs] = 0.14
    img[heart | mediast] = 0.62
    img[int(s * 0.80):, :][body[int(s * 0.80):, :] & ~lungs[int(s * 0.80):, :]] = 0.55  # diaphragm/abdomen

    # Ribs: faint posterior arcs over the lungs.
    yy, xx = np.mgrid[:s, :s]
    for k in range(9):
        y0 = s * 0.22 + k * s * 0.062
        arc = np.abs(yy - (y0 + 0.0009 * (xx - s / 2) ** 2 / (s / 512))) < s * 0.007
        img[arc & lungs] += 0.07

    # Vascular texture so lungs aren't flat.
    texture = ndimage.gaussian_filter(rng.normal(0, 1, (s, s)), 3) * 0.05
    img[lungs] += texture[lungs]

    if opacity:
        side, zone = opacity
        cx = r_cx if side == "right" else l_cx
        cy = {"upper": lung_cy - lung_ry * 0.5, "middle": lung_cy,
              "lower": lung_cy + lung_ry * 0.45}[zone]
        blob = np.exp(-(((yy - cy) / (s * 0.06)) ** 2 + ((xx - cx) / (s * 0.07)) ** 2))
        patchy = ndimage.gaussian_filter(rng.random((s, s)), 4)
        img += opacity_strength * blob * (0.75 + 0.5 * patchy) * lungs

    img = ndimage.gaussian_filter(img, 1.6)
    img += rng.normal(0, 0.012, img.shape)
    return np.clip(img, 0, 1)


# --------------------------------------------------------------------------- #
# Scenarios
# --------------------------------------------------------------------------- #
def _labs(d: dict[str, float]) -> list[LabValue]:
    from .reference import REFERENCE
    return [LabValue(k, v, REFERENCE.get(k, {}).get("unit", "")) for k, v in d.items()]


SCENARIOS = {
    "metabolic": dict(
        patient=Patient(
            "SYN-001", "Maria Lopez", 54, "F", 92, 165, "sedentary",
            history=["hypertension"], current_meds=["lisinopril 10 mg daily"],
            symptoms=["tiredness", "increased thirst", "passing urine often"],
            vitals={"bp": "142/88", "hr": 78, "rr": 16, "temp_c": 36.8, "spo2": 98},
        ),
        labs=dict(glucose=186, hba1c=8.4, total_chol=242, ldl=162, hdl=38, tg=260,
                  creatinine=0.9, bun=14, alt=48, ast=35, hemoglobin=13.2, mcv=88,
                  wbc=7.2, platelets=260, crp=4, potassium=4.3, sodium=139,
                  tsh=2.1, ferritin=90, vitamin_d=18, uacr=45, b12=410),
        ekg=dict(rhythm="sinus", hr=78), cxr=dict(ctr=0.44),
    ),
    "af_pneumonia": dict(
        patient=Patient(
            "SYN-002", "James Carter", 71, "M", 84, 178, "light",
            history=["hypertension"], current_meds=["amlodipine 5 mg daily"],
            allergies=["penicillin"],
            symptoms=["fluttering heartbeat", "cough with phlegm", "fever",
                      "short of breath on stairs"],
            vitals={"bp": "128/80", "hr": 118, "rr": 22, "temp_c": 38.6, "spo2": 93},
        ),
        labs=dict(glucose=118, hba1c=5.8, total_chol=198, ldl=118, hdl=46, tg=150,
                  creatinine=1.1, bun=18, alt=30, ast=28, hemoglobin=14.0, mcv=90,
                  wbc=15.8, platelets=310, crp=96, potassium=4.0, sodium=136,
                  tsh=1.8, ferritin=210, nt_probnp=450, b12=380),
        ekg=dict(rhythm="af", hr=118), cxr=dict(ctr=0.47, opacity=("right", "lower")),
    ),
    "anemia_ckd": dict(
        patient=Patient(
            "SYN-003", "Aisha Rahman", 63, "F", 58, 160, "light",
            history=["type 2 diabetes"], current_meds=["metformin 1000 mg twice daily"],
            symptoms=["tiredness", "breathless when walking", "ankle swelling"],
            diet_preference="vegetarian",
            vitals={"bp": "148/90", "hr": 106, "rr": 18, "temp_c": 36.9, "spo2": 97},
        ),
        labs=dict(glucose=140, hba1c=7.1, total_chol=182, ldl=96, hdl=50, tg=140,
                  creatinine=1.6, bun=32, alt=22, ast=20, hemoglobin=9.1, mcv=72,
                  wbc=6.0, platelets=380, crp=6, potassium=5.4, sodium=138,
                  tsh=3.0, ferritin=8, vitamin_d=22, uacr=320, nt_probnp=900, b12=240),
        ekg=dict(rhythm="sinus", hr=106), cxr=dict(ctr=0.58),
    ),
}


def build_case(name: str, seed: int = 7) -> CaseFile:
    sc = SCENARIOS[name]
    fs = 250
    case = CaseFile(
        patient=sc["patient"],
        labs=_labs(sc["labs"]),
        image=synth_cxr(seed=seed, **sc["cxr"]),
        ekg=synth_ekg(fs=fs, seed=seed, **sc["ekg"]),
        ekg_fs=fs,
        data_source=f"synthetic scenario '{name}'",
    )
    return case
