"""Classical image analysis for PA chest radiographs.

Steps: normalise -> segment lung fields (dark regions inside the body) ->
cardiothoracic ratio from the medial lung borders -> zone-by-zone density
comparison between left and right lungs to flag focal opacities.

This is a transparent heuristic, not a diagnostic model. It works on the
stylised synthetic images and can give rough measurements on real PA films
(e.g. public datasets), but every result is labelled for human review and
the agent abstains when segmentation fails sanity checks.
"""
from __future__ import annotations

import numpy as np
from scipy import ndimage


def _normalise(img: np.ndarray, size: int = 512) -> np.ndarray:
    img = np.asarray(img, dtype=float)
    if img.ndim == 3:
        img = img[..., :3].mean(axis=2)
    if img.shape != (size, size):
        img = ndimage.zoom(img, (size / img.shape[0], size / img.shape[1]), order=1)
    lo, hi = np.percentile(img, [1, 99])
    return np.clip((img - lo) / max(hi - lo, 1e-6), 0, 1)


def _otsu(vals: np.ndarray) -> float:
    hist, edges = np.histogram(vals, bins=128, range=(0, 1))
    p = hist / hist.sum()
    centres = (edges[:-1] + edges[1:]) / 2
    w = np.cumsum(p)
    mu = np.cumsum(p * centres)
    between = (mu[-1] * w - mu) ** 2 / (w * (1 - w) + 1e-12)
    return float(centres[np.nanargmax(between)])


def segment_lungs(img: np.ndarray):
    """Return (right_lung_mask, left_lung_mask) in PATIENT orientation
    (patient right = image left on a PA film), or None if implausible."""
    s = img.shape[0]
    body = ndimage.binary_fill_holes(img > 0.15)
    body = ndimage.binary_erosion(body, iterations=8)
    thr = _otsu(img[body])
    dark = (img < thr) & body
    dark = ndimage.binary_opening(dark, iterations=3)
    lab, n = ndimage.label(dark)
    if n < 2:
        return None
    sizes = ndimage.sum(dark, lab, range(1, n + 1))
    order = np.argsort(sizes)[::-1][:2] + 1
    masks = []
    for k in order:
        m = lab == k
        # Fill holes then close so focal opacities inside the lung remain in-field.
        m = ndimage.binary_closing(m, structure=np.ones((25, 25)))
        m = ndimage.binary_fill_holes(m)
        masks.append(m)
    cx = [ndimage.center_of_mass(m)[1] for m in masks]
    if abs(cx[0] - cx[1]) < s * 0.2:
        return None
    if min(m.sum() for m in masks) < 0.02 * s * s:
        return None
    right, left = (masks[0], masks[1]) if cx[0] < cx[1] else (masks[1], masks[0])
    return right, left


def analyze_cxr(raw: np.ndarray) -> dict:
    img = _normalise(raw)
    seg = segment_lungs(img)
    if seg is None:
        return {"quality": "unreadable",
                "note": "Could not identify two lung fields; image may not be a PA chest film."}
    right, left = seg
    lungs = right | left
    rows = np.where(lungs.any(axis=1))[0]
    out: dict = {"quality": "ok"}

    # Internal thoracic width: widest lateral extent of the lung fields.
    cols_any = np.where(lungs.any(axis=0))[0]
    thorax_w = cols_any[-1] - cols_any[0]

    # Heart width: in the lower half of the lung fields, the gap between the
    # right lung's medial edge and the left lung's medial edge.
    top, bot = rows[0], rows[-1]
    lower = range(int(top + 0.5 * (bot - top)), bot)
    gaps = []
    for r in lower:
        rc = np.where(right[r])[0]
        lc = np.where(left[r])[0]
        if len(rc) and len(lc):
            gaps.append(lc[0] - rc[-1])
    heart_w = float(np.percentile(gaps, 95)) if gaps else float("nan")
    ctr = heart_w / thorax_w if thorax_w else float("nan")
    out["cardiothoracic_ratio"] = round(ctr, 2)

    # Zone densities (upper/middle/lower thirds of each lung).
    zones = {}
    for side, m in (("right", right), ("left", left)):
        r = np.where(m.any(axis=1))[0]
        t, b = r[0], r[-1]
        thirds = np.linspace(t, b, 4).astype(int)
        for i, zone in enumerate(("upper", "middle", "lower")):
            zm = m.copy()
            zm[:thirds[i]] = False
            zm[thirds[i + 1]:] = False
            vals = img[zm]
            zones[f"{side}_{zone}"] = dict(
                mean=float(vals.mean()),
                p90=float(np.percentile(vals, 90)),
                n=int(zm.sum()),
            )
    out["zones"] = {k: round(v["mean"], 3) for k, v in zones.items()}

    lung_sd = float(img[lungs].std())
    opacities = []
    for zone in ("upper", "middle", "lower"):
        r, l = zones[f"right_{zone}"], zones[f"left_{zone}"]
        diff = r["p90"] - l["p90"]
        if abs(diff) > max(0.08, 0.9 * lung_sd):
            side = "right" if diff > 0 else "left"
            opacities.append({"side": side, "zone": zone,
                              "density_excess": round(abs(diff), 3)})
    out["opacities"] = opacities
    out["lung_symmetry_index"] = round(
        min(right.sum(), left.sum()) / max(right.sum(), left.sum()), 2)
    out["_masks"] = (right, left)
    out["_normalised"] = img
    return out
