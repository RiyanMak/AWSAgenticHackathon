"""Load your own (synthetic or public, de-identified) data.

Supported inputs
  patient  : JSON with Patient fields (see examples/patient_example.json)
  labs     : CSV, long format  (test,value[,unit])  or wide (one row, test names as headers)
  image    : PNG/JPG chest X-ray; DICOM if `pydicom` is installed
  ekg      : CSV (one column, or time,value), .npy, or a WFDB record (e.g. PhysioNet
             MIT-BIH / PTB-XL) if `wfdb` is installed - pass the record path without extension
"""
from __future__ import annotations

import csv
import json
from pathlib import Path

import numpy as np

from .models import CaseFile, LabValue, Patient
from .reference import ALIASES, REFERENCE


def _canon(name: str) -> str:
    k = name.strip().lower().replace(" ", "_").replace("-", "_")
    return ALIASES.get(k, k)


def load_patient(path: str | Path) -> Patient:
    return Patient(**json.loads(Path(path).read_text()))


def load_labs(path: str | Path) -> list[LabValue]:
    rows = list(csv.reader(Path(path).read_text().splitlines()))
    header = [h.strip().lower() for h in rows[0]]
    out = []
    if header[:2] == ["test", "value"]:
        for r in rows[1:]:
            if len(r) >= 2 and r[1].strip():
                key = _canon(r[0])
                out.append(LabValue(key, float(r[1]), r[2] if len(r) > 2 else REFERENCE.get(key, {}).get("unit", "")))
    else:  # wide: first data row
        for h, v in zip(rows[0], rows[1]):
            try:
                key = _canon(h)
                out.append(LabValue(key, float(v), REFERENCE.get(key, {}).get("unit", "")))
            except ValueError:
                continue
    return out


def load_image(path: str | Path) -> np.ndarray:
    path = Path(path)
    if path.suffix.lower() in (".dcm", ".dicom"):
        import pydicom
        ds = pydicom.dcmread(str(path))
        arr = ds.pixel_array.astype(float)
        if getattr(ds, "PhotometricInterpretation", "") == "MONOCHROME1":
            arr = arr.max() - arr
    else:
        from PIL import Image
        arr = np.asarray(Image.open(path).convert("L"), dtype=float)
    arr -= arr.min()
    return arr / max(arr.max(), 1e-9)


def load_ekg(path: str | Path, fs: int | None = None) -> tuple[np.ndarray, int]:
    path = Path(path)
    if path.suffix == ".npy":
        return np.load(path).astype(float).ravel(), fs or 250
    if path.suffix == ".csv":
        data = np.genfromtxt(path, delimiter=",", skip_header=1)
        if data.ndim == 2 and data.shape[1] >= 2:
            t, x = data[:, 0], data[:, 1]
            est = int(round(1 / np.median(np.diff(t)))) if np.median(np.diff(t)) > 0 else 250
            return x, fs or est
        return data.ravel(), fs or 250
    import wfdb                                   # PhysioNet record (path without extension)
    rec = wfdb.rdrecord(str(path))
    names = [n.upper() for n in rec.sig_name]
    ch = names.index("II") if "II" in names else names.index("MLII") if "MLII" in names else 0
    return rec.p_signal[:, ch].astype(float), int(rec.fs)


def build_custom_case(patient: str, labs: str | None = None, image: str | None = None,
                      ekg: str | None = None, ekg_fs: int | None = None,
                      max_seconds: float = 30) -> CaseFile:
    case = CaseFile(patient=load_patient(patient), data_source="user-supplied files")
    if labs:
        case.labs = load_labs(labs)
    if image:
        case.image = load_image(image)
    if ekg:
        x, fs = load_ekg(ekg, ekg_fs)
        case.ekg, case.ekg_fs = x[: int(max_seconds * fs)], fs
    return case
