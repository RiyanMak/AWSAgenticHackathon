"""Patient-friendly report writers (Markdown + self-contained HTML)."""
from __future__ import annotations

import base64
import html
import io
import json

import numpy as np

from .models import CaseFile

AVATAR = {"lab_analyst": "LA", "radiologist": "RX", "doctor": "MD", "nutritionist": "RD", "physio": "PT"}

DISCLAIMER = ("This report was produced by an educational multi-agent software demo using synthetic "
              "or public de-identified data. It is not medical advice. Diagnoses and prescriptions are "
              "drafts that a licensed clinician must review before anything is acted on.")

QUESTIONS = {
    "cap": "How will I know the antibiotic is working, and when should I call if it isn't?",
    "af": "What heart rate should I aim for, and how long will I need the blood thinner?",
    "t2dm": "What blood-sugar numbers should I aim for, and do I need a home glucose meter?",
    "ckd": "How can I protect my kidneys, and which over-the-counter medicines should I avoid?",
    "ida": "What tests will find out why my iron is low?",
    "hf_suspected": "When is my heart ultrasound, and what should I watch for until then?",
    "htn": "What blood-pressure target is right for me, and should I check it at home?",
    "lipids": "What cholesterol level are we aiming for?",
    "masld": "Do I need a liver scan, and how much weight loss would help?",
    "hyperk": "Which foods are highest in potassium, and when is my repeat blood test?",
}


# --------------------------------------------------------------------------- #
# Figures
# --------------------------------------------------------------------------- #
def _fig_b64(fig) -> str:
    buf = io.BytesIO()
    fig.savefig(buf, format="png", dpi=110, bbox_inches="tight", facecolor=fig.get_facecolor())
    import matplotlib.pyplot as plt
    plt.close(fig)
    return base64.b64encode(buf.getvalue()).decode()


def ekg_png(case: CaseFile) -> str | None:
    lab = case.reports.get("lab_analyst")
    if case.ekg is None or lab is None or lab.measurements.get("_ekg_filtered") is None:
        return None
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    x = lab.measurements["_ekg_filtered"]
    pk = lab.measurements["_ekg_peaks"]
    fs = case.ekg_fs
    n = min(len(x), 6 * fs)
    t = np.arange(n) / fs
    fig, ax = plt.subplots(figsize=(9, 2.2), facecolor="#fffaf3")
    ax.set_facecolor("#fffaf3")
    # ECG-paper grid: 0.2 s / 0.5 mV major, 0.04 s / 0.1 mV minor.
    for xv in np.arange(0, t[-1], 0.04):
        ax.axvline(xv, color="#f3c9c4", lw=0.3 if round(xv / 0.04) % 5 else 0.8, zorder=0)
    lo, hi = x[:n].min() - 0.2, x[:n].max() + 0.2
    for yv in np.arange(np.floor(lo * 10) / 10, hi, 0.1):
        ax.axhline(yv, color="#f3c9c4", lw=0.8 if abs(round(yv * 10) % 5) == 0 else 0.3, zorder=0)
    ax.plot(t, x[:n], color="#1f2937", lw=1.0)
    p = pk[pk < n]
    ax.plot(p / fs, x[p], "v", color="#c2410c", ms=5, label="detected beats")
    ax.set_xlim(0, t[-1]); ax.set_ylim(lo, hi)
    ax.set_xlabel("seconds"); ax.set_ylabel("mV")
    for s in ax.spines.values():
        s.set_visible(False)
    ax.legend(loc="upper center", bbox_to_anchor=(0.5, -0.32), frameon=False, fontsize=8)
    return _fig_b64(fig)


def cxr_png(case: CaseFile) -> str | None:
    rad = case.reports.get("radiologist")
    if case.image is None:
        return None
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    from .image_tools import _normalise
    img = _normalise(case.image)
    fig, ax = plt.subplots(figsize=(3.6, 3.6), facecolor="#111827")
    ax.imshow(img, cmap="gray")
    masks = rad.measurements.get("_cxr_masks") if rad else None
    if masks:
        for m in masks:
            ax.contour(m, levels=[0.5], colors=["#38bdf8"], linewidths=0.8)
    ax.text(8, 24, "R", color="white", fontsize=12, weight="bold")
    ax.text(img.shape[1] - 28, 24, "L", color="white", fontsize=12, weight="bold")
    ax.axis("off")
    return _fig_b64(fig)


# --------------------------------------------------------------------------- #
# Markdown
# --------------------------------------------------------------------------- #
def to_markdown(case: CaseFile) -> str:
    p = case.patient
    R = case.reports
    doc, lab, rad = R["doctor"].measurements, R["lab_analyst"], R["radiologist"]
    nut, phys = R["nutritionist"].measurements, R["physio"].measurements
    out = [f"# Your care-team report: {p.name}",
           f"*{p.age}-year-old {'man' if p.sex == 'M' else 'woman'} · ID {p.patient_id} · data: {case.data_source}*",
           "", f"> **{DISCLAIMER}**", "", f"## How soon to act\n**{doc['urgency']}**", ""]

    out.append("## What we found")
    for d in doc["diagnoses"]:
        out.append(f"### {d['plain_name']}  \n*{d['name']} — {d['certainty']}*\n\n{d['explanation']}\n")

    out.append("## Your test results")
    out.append("| Test | Your result | Usual range | |\n|---|---|---|---|")
    for r in lab.measurements["lab_table"]:
        flag = {"H": "⬆ high", "L": "⬇ low", "HH": "⚠ very high", "LL": "⚠ very low"}.get(r.get("flag"), "✓")
        out.append(f"| {r['test']} ({r.get('plain', '')}) | {r['value']} {r['unit']} | {r.get('range', '')} | {flag} |")
    ek = lab.measurements.get("ekg", {})
    if ek.get("quality") == "good":
        out.append(f"\n**Heart tracing (EKG):** {ek['rhythm'].replace('_', ' ')}, {ek['heart_rate_bpm']:.0f} beats/min, "
                   f"P waves in {ek['p_wave_fraction']:.0%} of beats, QRS {ek['qrs_ms']} ms.")
    if rad.measurements.get("cxr", {}).get("quality") == "ok":
        out.append(f"\n**Chest X-ray:** {rad.measurements['impression']} "
                   f"(heart-to-chest width ratio {rad.measurements['cxr']['cardiothoracic_ratio']}).")
    out.append("")

    out.append("## Your medicines (draft — needs your doctor's signature)")
    for r in R["doctor"].recommendations:
        out.append(f"- **{r['drug']} {r['dose']}**, {r['frequency']}, {r['duration']}  \n"
                   f"  *Why:* {r['purpose']}. *How:* {r['how_to_take']} *Watch for:* {r['side_effects']}")
    for c in doc["medication_changes"]:
        out.append(f"- **{c['action']}** — {c['drug']}: {c['reason']}")
    out.append("")

    out.append(f"## Your eating plan\n**About {nut['macros']['calories']} calories a day** to {nut['goal']}. "
               f"Protein ~{nut['macros']['protein_g']} g · carbs ~{nut['macros']['carbs_g']} g · "
               f"fat ~{nut['macros']['fat_g']} g · fibre {nut['macros']['fibre_g']} g · "
               f"sodium under {nut['macros']['sodium_mg_max']} mg.\n")
    for rule in nut["rules"]:
        out.append(f"- **{rule['topic']}:** {rule['advice']}")
    out.append("\n**A sample day**\n\n| Meal | Try this | Or swap for |\n|---|---|---|")
    for m in nut["meal_plan"]:
        out.append(f"| {m['meal'].title()} | {m['choice']} (~{m['kcal']} kcal) | {m['swap'] or ''} |")
    if nut["interactions"]:
        out.append("\n**Food and medicine tips**")
        out += [f"- {i}" for i in nut["interactions"]]
    out.append("")

    out.append(f"## Your movement plan\nEffort level: **{phys['intensity']}** — {phys['rpe']} on a 6-20 effort "
               f"scale. {phys['talk_test']}")
    for h in phys["holds"] + phys["caps"]:
        out.append(f"- ⚠ {h}")
    for ph in phys["phases"]:
        out.append(f"- **{ph['phase']}:** {ph['plan']}")
    out.append("\n| " + " | ".join(phys["week"]) + " |\n|" + "---|" * 7)
    out.append("| " + " | ".join("<br>".join(v) for v in phys["week"].values()) + " |")
    if phys["strength"] and phys["intensity"] not in ("none",):
        out.append("\n**Strength routine:** " + "; ".join(f"{n} ({r})" for n, r in phys["strength"]))
    out += [f"- {n}" for n in phys["notes"]]
    out.append("\n**Stop and rest (and get help if it doesn't pass) if you have:** " + "; ".join(phys["stop_signs"]) + ".\n")

    out.append("## Get help urgently if")
    out += [f"- {r}" for r in doc["red_flags"] or ["Any symptom that frightens you or gets rapidly worse"]]
    out.append("\n## Next steps\n**Tests:** " + "; ".join(doc["tests"]))
    if doc["referrals"]:
        out.append("\n**Referrals:** " + "; ".join(doc["referrals"]))
    out.append(f"\n**Follow-up:** {doc['follow_up']}\n")
    qs = [QUESTIONS[d["code"]] for d in doc["diagnoses"] if d["code"] in QUESTIONS]
    if qs:
        out.append("## Questions to ask your doctor")
        out += [f"- {q}" for q in qs]
    out.append("\n---\n### For clinicians: safety checks run\n" + "\n".join(f"- {s}" for s in doc["safety_log"]))
    out.append("\n### Team huddle\n" + "\n".join(f"- {s}" for s in doc["huddle"]))
    return "\n".join(out)


# --------------------------------------------------------------------------- #
# HTML
# --------------------------------------------------------------------------- #
def _e(s) -> str:
    return html.escape(str(s))


def to_html(case: CaseFile) -> str:
    p = case.patient
    R = case.reports
    doc, lab, rad = R["doctor"].measurements, R["lab_analyst"], R["radiologist"]
    nut, phys = R["nutritionist"].measurements, R["physio"].measurements
    urgency_level = doc["urgency"].split(" - ")[0]
    urg_cls = {"EMERGENCY": "u-em", "SAME DAY": "u-sd", "SOON": "u-soon"}.get(urgency_level, "u-rt")

    def persona_block(key, title, role, body):
        summary = R[key].patient_summary
        return (f'<section class="card"><header class="ph"><span class="av av-{key}">{AVATAR[key]}</span>'
                f'<div><h2>{_e(title)}</h2><p class="role">{_e(role)}</p></div></header>'
                f'<p class="voice">“{_e(summary)}”</p>{body}</section>')

    # Lab table
    rows = []
    for r in lab.measurements["lab_table"]:
        f = r.get("flag", "")
        cls = {"H": "hi", "L": "lo", "HH": "crit", "LL": "crit"}.get(f, "ok")
        txt = {"H": "High", "L": "Low", "HH": "Very high", "LL": "Very low"}.get(f, "Normal")
        rows.append(f'<tr><td><b>{_e(r["test"])}</b><br><small>{_e(r.get("plain", ""))}</small></td>'
                    f'<td class="num">{_e(r["value"])} <small>{_e(r["unit"])}</small></td>'
                    f'<td class="num"><small>{_e(r.get("range", ""))}</small></td>'
                    f'<td><span class="pill {cls}">{txt}</span></td></tr>')
    ek = lab.measurements.get("ekg", {})
    ekg_img = ekg_png(case)
    ekg_html = ""
    if ekg_img:
        ekg_html = (f'<h3>Heart tracing (EKG, lead II)</h3><img class="ekg" alt="EKG trace" src="data:image/png;base64,{ekg_img}">'
                    f'<div class="stats"><div><b>{ek["heart_rate_bpm"]:.0f}</b><span>beats/min</span></div>'
                    f'<div><b>{_e(ek["rhythm"].replace("_", " ").capitalize())}</b><span>rhythm</span></div>'
                    f'<div><b>{ek["p_wave_fraction"]:.0%}</b><span>beats with P wave</span></div>'
                    f'<div><b>{ek["rr_cv"]}</b><span>beat-to-beat variability</span></div>'
                    f'<div><b>{ek["qrs_ms"]:.0f} ms</b><span>QRS width</span></div></div>')
    lab_body = (f'<table class="labs"><thead><tr><th>Test</th><th>Result</th><th>Usual</th><th></th></tr></thead>'
                f'<tbody>{"".join(rows)}</tbody></table>'
                + (f'<p class="meta">Kidney filtration (eGFR): <b>{lab.measurements["egfr"]:.0f}</b> · stage '
                   f'{_e(lab.measurements["ckd_stage"])}</p>' if "egfr" in lab.measurements else "")
                + ekg_html)

    cxr_img = cxr_png(case)
    cm = rad.measurements.get("cxr", {})
    rad_body = ""
    if cxr_img:
        rad_body = (f'<div class="cxr"><img alt="Chest X-ray with outlined lungs" src="data:image/png;base64,{cxr_img}">'
                    f'<div><p><b>Impression:</b> {_e(rad.measurements.get("impression", "not available"))}</p>'
                    f'<p><b>Heart-to-chest ratio:</b> {_e(cm.get("cardiothoracic_ratio", "-"))} '
                    f'<small>(normal ≤ 0.50)</small></p>'
                    + (f'<p class="second"><b>Vision-model second read:</b> {_e(rad.measurements["vision_second_read"])}</p>'
                       if "vision_second_read" in rad.measurements else "")
                    + "".join(f'<p class="warn">{_e(w)}</p>' for w in rad.warnings) + "</div></div>")

    dx_html = "".join(
        f'<div class="dx"><h3>{_e(d["plain_name"])}</h3><p class="tech">{_e(d["name"])} · '
        f'<em>{_e(d["certainty"])}</em></p><p>{_e(d["explanation"])}</p></div>' for d in doc["diagnoses"])
    meds_html = "".join(
        f'<div class="med"><h4>{_e(r["drug"])} <span>{_e(r["dose"])}</span></h4>'
        f'<p class="when">{_e(r["frequency"])} · {_e(r["duration"])}</p>'
        f'<p><b>Why:</b> {_e(r["purpose"])}</p><p><b>How:</b> {_e(r["how_to_take"])}</p>'
        f'<p><b>Watch for:</b> {_e(r["side_effects"])}</p></div>' for r in R["doctor"].recommendations)
    changes_html = "".join(
        f'<li><b>{_e(c["action"])}</b> — {_e(c["drug"])}: {_e(c["reason"])}</li>' for c in doc["medication_changes"])
    doc_body = (f'<div class="dxs">{dx_html}</div><h3>Medicines (draft)</h3><div class="meds">{meds_html or "<p>No new medicines.</p>"}</div>'
                + (f'<h3>Changes to your current medicines</h3><ul>{changes_html}</ul>' if changes_html else "")
                + '<div class="cols"><div><h3>Tests</h3><ul>' + "".join(f"<li>{_e(t)}</li>" for t in doc["tests"]) + "</ul></div>"
                + '<div><h3>Referrals &amp; follow-up</h3><ul>' + "".join(f"<li>{_e(t)}</li>" for t in doc["referrals"])
                + f'<li>Follow-up: {_e(doc["follow_up"])}</li></ul></div></div>')

    m = nut["macros"]
    nut_body = (f'<div class="stats"><div><b>{m["calories"]}</b><span>kcal / day</span></div>'
                f'<div><b>{m["protein_g"]} g</b><span>protein</span></div><div><b>{m["carbs_g"]} g</b><span>carbs</span></div>'
                f'<div><b>{m["fat_g"]} g</b><span>fat</span></div><div><b>&lt;{m["sodium_mg_max"]} mg</b><span>sodium</span></div></div>'
                f'<p class="meta">Goal: {_e(nut["goal"])}</p>'
                + "".join(f'<div class="rule"><h4>{_e(r["topic"])}</h4><p>{_e(r["advice"])}</p><p class="why">Why: {_e(r["why"])}</p></div>'
                          for r in nut["rules"])
                + '<h3>A sample day</h3><table class="meals"><tbody>'
                + "".join(f'<tr><th>{_e(x["meal"].title())}</th><td>{_e(x["choice"])} <small>~{x["kcal"]} kcal</small>'
                          f'<br><small class="swap">or: {_e(x["swap"] or "-")}</small></td></tr>' for x in nut["meal_plan"])
                + "</tbody></table>"
                + ("<h3>Food &amp; medicine tips</h3><ul>" + "".join(f"<li>{_e(i)}</li>" for i in nut["interactions"]) + "</ul>"
                   if nut["interactions"] else "")
                + "".join(f'<p class="note">{_e(w)}</p>' for w in R["nutritionist"].warnings))

    week = "".join(f'<div class="day"><b>{d}</b>' + "".join(f"<span>{_e(i)}</span>" for i in items) + "</div>"
                   for d, items in phys["week"].items())
    phys_body = (f'<div class="stats"><div><b>{_e(phys["intensity"])}</b><span>effort level</span></div>'
                 f'<div><b>{_e(phys["rpe"])}</b><span>effort scale (6-20)</span></div>'
                 f'<div><b>{_e(phys["talk_test"])}</b><span>talk test</span></div>'
                 + (f'<div><b>{phys["hr_zone"][0]}-{phys["hr_zone"][1]}</b><span>heart-rate zone</span></div>' if phys["hr_zone"] else "")
                 + "</div>"
                 + "".join(f'<p class="warn">{_e(h)}</p>' for h in phys["holds"] + phys["caps"])
                 + '<ol class="phases">' + "".join(f"<li><b>{_e(x['phase'])}:</b> {_e(x['plan'])}</li>" for x in phys["phases"]) + "</ol>"
                 + f'<div class="week">{week}</div>'
                 + ("<h3>Strength routine</h3><ul>" + "".join(f"<li>{_e(n)} — {_e(r)}</li>" for n, r in phys["strength"]) + "</ul>"
                    if phys["intensity"] != "none" else "")
                 + ("<h3>Breathing exercises</h3><ul>" + "".join(f"<li>{_e(n)} — {_e(r)}</li>" for n, r in phys["breathing"]) + "</ul>"
                    if phys["breathing"] else "")
                 + ("<h3>Balance</h3><ul>" + "".join(f"<li>{_e(n)} — {_e(r)}</li>" for n, r in phys["balance"]) + "</ul>"
                    if phys["balance"] else "")
                 + "<ul>" + "".join(f"<li>{_e(n)}</li>" for n in phys["notes"]) + "</ul>"
                 + '<p class="stop"><b>Stop and rest if you notice:</b> ' + _e("; ".join(phys["stop_signs"])) + ".</p>")

    qs = [QUESTIONS[d["code"]] for d in doc["diagnoses"] if d["code"] in QUESTIONS]
    flags = doc["red_flags"] or ["Any symptom that frightens you or gets rapidly worse"]

    return f"""<!doctype html><html lang="en"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Care Report · {_e(p.name)}</title>
<link href="https://fonts.googleapis.com/css2?family=Fraunces:opsz,wght@9..144,500;9..144,650&family=Inter:wght@400;500;600&display=swap" rel="stylesheet">
<style>
:root{{--bg:#f6f3ee;--card:#fffdf9;--ink:#1c2321;--mute:#5d6662;--line:#e5ded3;--accent:#0f766e;
--hi:#b45309;--lo:#1d4ed8;--crit:#b91c1c;--ok:#15803d;--soft:#eef6f4}}
@media (prefers-color-scheme:dark){{:root:not([data-theme=light]){{--bg:#141816;--card:#1b201e;--ink:#e8ece9;--mute:#9aa49f;
--line:#2c3330;--accent:#2dd4bf;--hi:#f59e0b;--lo:#60a5fa;--crit:#f87171;--ok:#4ade80;--soft:#1f2a27}}}}
*{{box-sizing:border-box}}body{{margin:0;background:var(--bg);color:var(--ink);font:16px/1.6 Inter,system-ui,sans-serif}}
main{{max-width:980px;margin:0 auto;padding:32px 16px 64px}}
h1,h2,h3,h4{{font-family:Fraunces,Georgia,serif;font-weight:650;line-height:1.2;margin:0}}
h1{{font-size:clamp(28px,5vw,42px)}}h2{{font-size:22px}}h3{{font-size:18px;margin:22px 0 10px}}h4{{font-size:16px}}
.sub{{color:var(--mute);margin:6px 0 18px}}
.banner{{border-radius:14px;padding:14px 18px;font-weight:600;margin:18px 0;border:1px solid}}
.u-em{{background:#fee2e2;color:#7f1d1d;border-color:#fca5a5}}.u-sd{{background:#ffedd5;color:#7c2d12;border-color:#fdba74}}
.u-soon{{background:#fef9c3;color:#713f12;border-color:#fde047}}.u-rt{{background:#dcfce7;color:#14532d;border-color:#86efac}}
.disc{{font-size:13px;color:var(--mute);border-left:3px solid var(--accent);padding:6px 12px;background:var(--soft);border-radius:0 8px 8px 0}}
.card{{background:var(--card);border:1px solid var(--line);border-radius:18px;padding:22px;margin:20px 0}}
.ph{{display:flex;gap:14px;align-items:center;margin-bottom:8px}}.role{{margin:0;color:var(--mute);font-size:14px}}
.av{{width:44px;height:44px;border-radius:50%;display:grid;place-items:center;font-weight:600;color:#fff;flex:none}}
.av-lab_analyst{{background:#7c3aed}}.av-radiologist{{background:#0369a1}}.av-doctor{{background:#0f766e}}
.av-nutritionist{{background:#c2410c}}.av-physio{{background:#be185d}}
.voice{{font-style:italic;color:var(--mute);border-left:2px solid var(--line);padding-left:12px}}
table{{width:100%;border-collapse:collapse;font-size:15px}}td,th{{padding:8px 6px;border-bottom:1px solid var(--line);text-align:left;vertical-align:top}}
.num{{white-space:nowrap}}small{{color:var(--mute)}}
.labs-wrap{{overflow-x:auto}}
.pill{{font-size:12px;font-weight:600;padding:2px 9px;border-radius:999px;white-space:nowrap}}
.pill.ok{{color:var(--ok);background:color-mix(in srgb,var(--ok) 12%,transparent)}}.pill.hi{{color:var(--hi);background:color-mix(in srgb,var(--hi) 14%,transparent)}}
.pill.lo{{color:var(--lo);background:color-mix(in srgb,var(--lo) 14%,transparent)}}.pill.crit{{color:#fff;background:var(--crit)}}
.ekg{{width:100%;border-radius:10px;border:1px solid var(--line)}}
.stats{{display:grid;grid-template-columns:repeat(auto-fit,minmax(130px,1fr));gap:10px;margin:12px 0}}
.stats div{{background:var(--soft);border-radius:12px;padding:10px 12px}}.stats b{{display:block;font-size:17px}}
.stats span{{font-size:12px;color:var(--mute)}}
.cxr{{display:grid;grid-template-columns:minmax(0,300px) 1fr;gap:18px;align-items:start}}.cxr img{{width:100%;border-radius:12px}}
@media (max-width:640px){{.cxr{{grid-template-columns:1fr}}}}
.warn{{color:var(--hi);font-size:14px;margin:6px 0}}.note,.meta{{font-size:14px;color:var(--mute)}}
.second{{font-size:14px;background:var(--soft);padding:8px 10px;border-radius:8px}}
.dxs{{display:grid;gap:12px}}.dx{{border:1px solid var(--line);border-radius:14px;padding:14px 16px}}
.dx p{{margin:6px 0 0}}.tech{{font-size:13px;color:var(--mute)}}
.meds{{display:grid;grid-template-columns:repeat(auto-fit,minmax(260px,1fr));gap:12px}}
.med{{border:1px solid var(--line);border-radius:14px;padding:14px;background:var(--soft)}}.med p{{margin:4px 0;font-size:14px}}
.med h4 span{{font-family:Inter;font-size:14px;color:var(--accent)}}.when{{font-weight:600}}
.cols{{display:grid;grid-template-columns:1fr 1fr;gap:18px}}@media (max-width:640px){{.cols{{grid-template-columns:1fr}}}}
.rule{{border-top:1px solid var(--line);padding:10px 0}}.rule p{{margin:4px 0}}.why{{font-size:13px;color:var(--mute)}}
.meals th{{width:110px;font-family:Fraunces,serif}}.swap{{font-style:italic}}
.week{{display:grid;grid-template-columns:repeat(7,minmax(0,1fr));gap:6px;margin:12px 0}}
@media (max-width:640px){{.week{{grid-template-columns:repeat(2,1fr)}}}}
.day{{background:var(--soft);border-radius:10px;padding:8px;font-size:12.5px;display:flex;flex-direction:column;gap:4px}}
.day b{{font-size:13px}}.day span{{background:var(--card);border-radius:6px;padding:3px 5px}}
.stop{{background:color-mix(in srgb,var(--crit) 10%,transparent);border-radius:10px;padding:10px 12px;font-size:14px}}
.flags li{{margin:4px 0}}details{{font-size:13px;color:var(--mute)}}summary{{cursor:pointer;font-weight:600}}
</style></head><body><main>
<p class="sub">Care-team report · generated by 5 AI personas · {_e(case.data_source)}</p>
<h1>{_e(p.name)}</h1>
<p class="sub">{p.age} · {'Male' if p.sex == 'M' else 'Female'} · BMI {p.bmi} · BP {_e(p.vitals.get('bp', '-'))} ·
temp {_e(p.vitals.get('temp_c', '-'))}°C · SpO₂ {_e(p.vitals.get('spo2', '-'))}%</p>
<div class="banner {urg_cls}">{_e(doc['urgency'])}</div>
<p class="disc">{_e(DISCLAIMER)}</p>
{persona_block('doctor', 'What it all means', 'Doctor — integrates every result', doc_body)}
{persona_block('lab_analyst', 'Your test results', 'Lab Analyst — blood, urine & EKG', '<div class="labs-wrap">' + lab_body + '</div>')}
{persona_block('radiologist', 'Your chest X-ray', 'Radiologist — imaging', rad_body or '<p>No image provided.</p>')}
{persona_block('nutritionist', 'Your eating plan', 'Nutritionist — food & medicine', nut_body)}
{persona_block('physio', 'Your movement plan', 'Physiotherapist — safe exercise', phys_body)}
<section class="card"><h2>Get help urgently if</h2><ul class="flags">{''.join(f'<li>{_e(f)}</li>' for f in flags)}</ul>
{('<h3>Questions to ask your doctor</h3><ul>' + ''.join(f'<li>{_e(q)}</li>' for q in qs) + '</ul>') if qs else ''}</section>
<section class="card"><details><summary>For clinicians: safety checks, risk scores and agent trace</summary>
<p><b>Risk scores:</b> {_e(json.dumps(doc['risk_scores']))}</p>
<ul>{''.join(f'<li>{_e(s)}</li>' for s in doc['safety_log'])}</ul>
<p><b>Team huddle:</b></p><ul>{''.join(f'<li>{_e(s)}</li>' for s in doc['huddle'])}</ul>
<p><b>Trace:</b></p><ol>{''.join(f'<li>{_e(t)}</li>' for t in case.trace)}</ol></details></section>
</main></body></html>"""


def to_json(case: CaseFile) -> str:
    def clean(o):
        if isinstance(o, dict):
            return {k: clean(v) for k, v in o.items() if not str(k).startswith("_")}
        if isinstance(o, (list, tuple)):
            return [clean(v) for v in o]
        if isinstance(o, np.generic):
            return o.item()
        return o
    data = {
        "patient": clean(vars(case.patient)),
        "data_source": case.data_source,
        "reports": {k: clean({"persona": r.persona, "findings": [f.to_dict() for f in r.findings],
                              "measurements": r.measurements, "recommendations": r.recommendations,
                              "patient_summary": r.patient_summary, "warnings": r.warnings})
                    for k, r in case.reports.items()},
        "trace": case.trace,
    }
    return json.dumps(data, indent=2, default=str)
