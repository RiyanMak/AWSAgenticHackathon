# MedTeam — a five-persona healthcare agent team

An educational multi-agent system in which five AI personas analyse a patient's
**lab results**, **chest X-ray** and **EKG time series**, then produce a
patient-friendly report with diagnoses, draft prescriptions, a nutrition plan
and an exercise programme.

> ⚠️ **Synthetic / public de-identified data only. Not a medical device and not
> medical advice.** Every diagnosis and prescription is a draft that a licensed
> clinician must review.

## The team

| Persona | Reads | Produces |
|---|---|---|
| **Lab Analyst** | blood/urine chemistry, EKG lead II | flagged results, eGFR (CKD-EPI 2021) & CKD stage, pattern findings (diabetes, anaemia type, iron deficiency, infection, …), rhythm analysis (HR, RR variability, P-wave detection, QRS width → sinus / tachy / brady / AF) |
| **Radiologist** | PA chest radiograph | lung segmentation, cardiothoracic ratio, zone-by-zone opacity detection; abstains on unreadable images; optional Claude-vision second read |
| **Doctor** | both reports + vitals/history | diagnosis list with certainty, triage level, risk scores (CHA₂DS₂-VASc, CURB-65), draft prescriptions with safety checks (allergies, renal dosing, interactions), medication changes, tests, referrals, red flags |
| **Nutritionist** | Doctor's plan | calorie target (Mifflin-St Jeor), macros, condition rules (diabetes, CKD, potassium, iron, salt, illness), food–drug interactions, a sample day of meals honouring diet preference |
| **Physiotherapist** | Doctor's plan | readiness gates (fever, AF rate, Hb, heart strain), intensity, RPE/talk test or HR zone, phased progression, weekly schedule, strength/breathing/balance work, stop signs |

### How they collaborate

```
Stage 1   Lab Analyst  ║  Radiologist        (parallel, raw data → findings)
             └──────┬──────┘
Stage 2          Doctor                      (findings → diagnosis + plan)
             ┌──────┴──────┐
Stage 3   Nutritionist ║  Physiotherapist    (parallel, plan → lifestyle)
                    │
            Team huddle (cross-checks)  →  HTML / Markdown / JSON report
```

Agents share a single `CaseFile` blackboard and declare `depends_on`; the
orchestrator derives the stages. Examples of cross-agent reasoning:

- Doctor **reduces metformin** because the Lab Analyst's eGFR is 36, and
  **defers an ARB** because potassium is 5.4.
- Doctor picks **levofloxacin** over amoxicillin because of a penicillin
  allergy and avoids clarithromycin because apixaban is co-prescribed.
- Nutritionist resolves an **iron-vs-potassium conflict** (spinach and lentils
  are iron-rich but high in potassium) and adds dose-spacing for iron and
  antibiotics.
- Physio switches from heart-rate zones to **effort scale** when the patient
  has AF, takes a beta-blocker or has a fast resting rate from anaemia.

## Quick start

```bash
pip install -r requirements.txt
python run.py                              # 3 synthetic patients → reports/
python run.py --scenario anemia_ckd
python -m pytest -q                        # 11 tests
```

Each run writes `reports/<id>_<scenario>.html` (patient-facing, self-contained,
with the EKG strip and X-ray), `.md` and `.json`.

### Synthetic scenarios

| Scenario | Patient | Key data |
|---|---|---|
| `metabolic` | 54 F, BMI 33.8, hypertension | new type 2 diabetes, high LDL/TG, albuminuria, low vitamin D; normal EKG and CXR |
| `af_pneumonia` | 71 M, penicillin allergy | AF at ~120 bpm, right-lower-lobe opacity, WBC 15.8, CRP 96, fever |
| `anemia_ckd` | 63 F, vegetarian, diabetes on metformin | Hb 9.1 microcytic, ferritin 8, eGFR 36, K 5.4, uACR 320, cardiomegaly (CTR 0.57), sinus tachycardia |

### Your own (public / synthetic) data

```bash
python run.py --patient examples/patient_example.json \
              --labs examples/labs_example.csv \
              --image some_cxr.png \
              --ekg some_ekg.csv --ekg-fs 360
```

- **Labs:** CSV `test,value[,unit]` or a one-row wide CSV. Common aliases
  (`A1C`, `Hgb`, `K`, …) are mapped automatically.
- **Image:** PNG/JPG, or DICOM with `pydicom`. Public sets such as NIH
  ChestX-ray14 or the Montgomery/Shenzhen TB sets work as inputs; the
  classical heuristics are rough on real films and the Radiologist abstains
  when segmentation looks implausible.
- **EKG:** CSV (one column, or `time,value`), `.npy`, or a PhysioNet WFDB
  record (MIT-BIH, PTB-XL) with `wfdb` installed — lead II/MLII is used.

## Using Claude for persona narration

```bash
pip install anthropic
export ANTHROPIC_API_KEY=...
python run.py --llm                 # optional: --model <model-id>  (default claude-sonnet-5-5, or $MEDTEAM_MODEL)
```

With the LLM on, each persona rewrites its patient summary in its own voice,
and the Radiologist sends the image for a vision second read. **The LLM never
changes structured findings, drugs or doses** — those come from the rule
engine so the safety checks always run. Without a key everything works
offline.

## Project layout

```
medteam/
  models.py          Patient, LabValue, Finding, AgentReport, CaseFile (blackboard)
  reference.py       reference ranges, plain-language names, aliases
  synthetic.py       synthetic labs, stylised CXR images, EKG generator, scenarios
  signal_tools.py    EKG filtering, R-peaks, HRV, P-wave template test, QRS width
  image_tools.py     lung segmentation, CTR, zone opacity detection
  llm.py             optional Claude wrapper (text + image)
  agents/            lab_analyst, radiologist, doctor, nutritionist, physio
  orchestrator.py    staged parallel execution + team huddle
  report.py          HTML / Markdown / JSON writers
  loaders.py         CSV / PNG / DICOM / WFDB loaders
run.py               CLI
tests/               unit + end-to-end tests
```

## Extending

- **New persona:** subclass `Agent`, set `name`, `persona`, `depends_on`,
  implement `analyze(case) -> AgentReport`, and add it to `CareTeam.agents`
  (e.g. a Pharmacist that depends on `doctor`, or a Cardiologist on `lab_analyst`).
- **Better models:** swap `analyze_cxr` / `analyze_ekg` for a trained model
  (e.g. a CheXpert-style CNN or a PTB-XL rhythm classifier) — the agents only
  consume the returned dict.

## Limitations

The clinical rules are a compact teaching scaffold loosely modelled on common
guideline defaults; they are incomplete and not validated. The image analysis
is a transparent heuristic tuned on stylised synthetic films. Do not use with
real patients.
