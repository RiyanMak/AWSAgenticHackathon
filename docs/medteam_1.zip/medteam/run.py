#!/usr/bin/env python3
"""Run the five-persona care team.

Examples
  python run.py                                   # all three synthetic scenarios
  python run.py --scenario af_pneumonia
  python run.py --patient examples/patient_example.json --labs examples/labs_example.csv \
                --image my_cxr.png --ekg my_ekg.csv --ekg-fs 360
  ANTHROPIC_API_KEY=... python run.py --llm       # personas narrate with Claude
"""
from __future__ import annotations

import argparse
from pathlib import Path

from medteam.llm import LLM
from medteam.loaders import build_custom_case
from medteam.orchestrator import CareTeam
from medteam.report import to_html, to_json, to_markdown
from medteam.synthetic import SCENARIOS, build_case


def main() -> None:
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--scenario", choices=list(SCENARIOS) + ["all"], default="all")
    ap.add_argument("--patient", help="patient JSON (switches to custom data mode)")
    ap.add_argument("--labs"); ap.add_argument("--image"); ap.add_argument("--ekg")
    ap.add_argument("--ekg-fs", type=int)
    ap.add_argument("--out", default="reports")
    ap.add_argument("--llm", action="store_true", help="use Claude for persona narration (needs ANTHROPIC_API_KEY)")
    ap.add_argument("--model", help="override Claude model id")
    ap.add_argument("--quiet", action="store_true")
    a = ap.parse_args()

    llm = LLM(model=a.model, enabled=a.llm)
    if a.llm and not llm.available:
        print("! --llm requested but ANTHROPIC_API_KEY / anthropic SDK not available; using offline mode")
    team = CareTeam(llm)
    out = Path(a.out); out.mkdir(parents=True, exist_ok=True)

    if a.patient:
        cases = [("custom", build_custom_case(a.patient, a.labs, a.image, a.ekg, a.ekg_fs))]
    else:
        names = list(SCENARIOS) if a.scenario == "all" else [a.scenario]
        cases = [(n, build_case(n)) for n in names]

    for name, case in cases:
        team.run(case)
        stem = f"{case.patient.patient_id}_{name}"
        (out / f"{stem}.html").write_text(to_html(case))
        (out / f"{stem}.md").write_text(to_markdown(case))
        (out / f"{stem}.json").write_text(to_json(case))
        if not a.quiet:
            print("\n".join(case.trace))
            doc = case.reports["doctor"].measurements
            print(f"  -> {doc['urgency']}")
            print(f"  -> diagnoses: {', '.join(d['plain_name'] for d in doc['diagnoses'])}")
            print(f"  -> wrote {out / stem}.html|.md|.json\n")


if __name__ == "__main__":
    main()
