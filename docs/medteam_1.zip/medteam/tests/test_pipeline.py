"""End-to-end and unit tests. Run: python -m pytest -q"""
import json
import sys
from collections import Counter
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from medteam.agents.lab_analyst import egfr_ckd_epi_2021
from medteam.image_tools import analyze_cxr
from medteam.loaders import build_custom_case
from medteam.orchestrator import CareTeam
from medteam.report import to_html, to_json, to_markdown
from medteam.signal_tools import analyze_ekg
from medteam.synthetic import build_case, synth_cxr, synth_ekg

ROOT = Path(__file__).resolve().parents[1]


def run(name):
    return CareTeam().run(build_case(name))


# ---- signal / image tools ------------------------------------------------
def test_ekg_classifier_accuracy():
    af = Counter(analyze_ekg(synth_ekg("af", hr, seed=s), 250)["rhythm"] for hr in (70, 100, 130) for s in range(10))
    sinus = Counter(analyze_ekg(synth_ekg("sinus", hr, seed=s), 250)["rhythm"] for hr in (60, 80) for s in range(10))
    assert af["atrial_fibrillation"] >= 28
    assert sinus["normal_sinus_rhythm"] == 20


def test_ekg_rate_and_qrs():
    o = analyze_ekg(synth_ekg("sinus", 72, seed=1), 250)
    assert abs(o["heart_rate_bpm"] - 72) <= 3
    assert 60 <= o["qrs_ms"] <= 110
    assert analyze_ekg(synth_ekg("sinus", 75, qrs_ms=160, seed=1), 250)["qrs_ms"] >= 120


def test_cxr_measurements():
    assert abs(analyze_cxr(synth_cxr(ctr=0.58))["cardiothoracic_ratio"] - 0.58) <= 0.03
    ops = analyze_cxr(synth_cxr(opacity=("left", "upper")))["opacities"]
    assert ops and ops[0]["side"] == "left" and ops[0]["zone"] == "upper"
    assert analyze_cxr(synth_cxr())["opacities"] == []


def test_radiologist_abstains_on_non_cxr():
    assert analyze_cxr(np.random.default_rng(0).random((256, 256)))["quality"] == "unreadable"


def test_egfr_known_value():
    assert egfr_ckd_epi_2021(1.6, 63, "F") == 36


# ---- multi-agent pipeline -----------------------------------------------
def test_metabolic_case():
    c = run("metabolic")
    dx = {d["code"] for d in c.reports["doctor"].measurements["diagnoses"]}
    assert {"t2dm", "lipids", "obesity"} <= dx
    drugs = {r["drug"] for r in c.reports["doctor"].recommendations}
    assert {"Metformin", "Atorvastatin"} <= drugs
    assert c.reports["doctor"].measurements["urgency"].startswith("ROUTINE")
    assert c.reports["physio"].measurements["intensity"] == "moderate"


def test_af_pneumonia_case_safety():
    c = run("af_pneumonia")
    doc = c.reports["doctor"]
    drugs = {r["drug"] for r in doc.recommendations}
    assert "Apixaban" in drugs and "Levofloxacin" in drugs
    assert not any("amoxicillin" in d.lower() for d in drugs), "penicillin allergy must be respected"
    assert doc.measurements["risk_scores"]["CHA2DS2-VASc"] == 2
    assert doc.measurements["urgency"].startswith("SAME DAY")
    assert c.reports["physio"].measurements["intensity"] == "recovery"
    assert any("2 hours" in i for i in c.reports["nutritionist"].measurements["interactions"])


def test_anemia_ckd_case_safety():
    c = run("anemia_ckd")
    doc = c.reports["doctor"].measurements
    changes = {ch["drug"]: ch["action"] for ch in doc["medication_changes"]}
    assert changes["Metformin"].startswith("REDUCE")          # eGFR 36
    assert any(a == "DEFER" for a in changes.values())          # ARB held for K 5.4
    plan = c.reports["nutritionist"].measurements["meal_plan"]
    assert not any("banana" in m["choice"].lower() or "spinach" in m["choice"].lower() for m in plan)
    assert all("chicken" not in m["choice"].lower() and "salmon" not in m["choice"].lower() for m in plan)
    assert c.reports["physio"].measurements["intensity"] == "light"
    assert c.reports["physio"].measurements["use_rpe"] is True


def test_reports_render():
    c = run("af_pneumonia")
    h, md, js = to_html(c), to_markdown(c), json.loads(to_json(c))
    assert "data:image/png;base64" in h and "Apixaban" in h
    assert "## Your medicines" in md
    assert set(js["reports"]) == {"lab_analyst", "radiologist", "doctor", "nutritionist", "physio"}


def test_custom_inputs(tmp_path):
    ex = ROOT / "examples"
    ekg = tmp_path / "ekg.csv"
    np.savetxt(ekg, synth_ekg("sinus", 64, seed=3), delimiter=",", header="mv", comments="")
    from PIL import Image
    img = tmp_path / "cxr.png"
    Image.fromarray((synth_cxr() * 255).astype("uint8")).save(img)
    c = build_custom_case(str(ex / "patient_example.json"), str(ex / "labs_example.csv"), str(img), str(ekg), 250)
    CareTeam().run(c)
    assert c.reports["lab_analyst"].measurements["ekg"]["rhythm"] == "normal_sinus_rhythm"
    assert "prediabetes" in c.reports["lab_analyst"].codes()


def test_llm_narration_path_with_stub():
    """The Claude path is exercised with a stub so tests run offline."""
    from medteam.llm import LLM

    class Stub(LLM):
        def __init__(self):
            super().__init__(enabled=False)
            self.calls = []

        @property
        def available(self):
            return True

        def ask(self, system, prompt, image=None, max_tokens=900):
            self.calls.append((system, image is not None))
            return "Plain-language summary from the persona."

    stub = Stub()
    c = CareTeam(stub).run(build_case("af_pneumonia"))
    assert c.reports["doctor"].patient_summary == "Plain-language summary from the persona."
    assert any(has_img for _, has_img in stub.calls), "radiologist should send the image"
    assert {r["drug"] for r in c.reports["doctor"].recommendations} >= {"Apixaban"}  # structure untouched
